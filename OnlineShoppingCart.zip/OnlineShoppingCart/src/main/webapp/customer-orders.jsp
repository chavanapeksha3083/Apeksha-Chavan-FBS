<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if (session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String username = (String) session.getAttribute("username");
    int userId = (Integer) session.getAttribute("userId");

    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";

    List<Map<String, Object>> orders = new ArrayList<>();
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

        String orderSql = "SELECT order_id, total_amount, status, payment_method, order_date FROM orders WHERE user_id = ? ORDER BY order_date DESC";
        PreparedStatement orderStmt = con.prepareStatement(orderSql);
        orderStmt.setInt(1, userId);
        ResultSet orderRs = orderStmt.executeQuery();

        while (orderRs.next()) {
            Map<String, Object> order = new HashMap<>();
            int orderId = orderRs.getInt("order_id");
            order.put("orderId", orderId);
            order.put("total", orderRs.getDouble("total_amount"));
            order.put("status", orderRs.getString("status"));
            order.put("paymentMethod", orderRs.getString("payment_method"));
            order.put("date", orderRs.getTimestamp("order_date"));

            // Fetch items for this order
            List<Map<String, Object>> items = new ArrayList<>();
            String itemSql = "SELECT product_name, product_price, product_image, quantity FROM order_items WHERE order_id = ?";
            PreparedStatement itemStmt = con.prepareStatement(itemSql);
            itemStmt.setInt(1, orderId);
            ResultSet itemRs = itemStmt.executeQuery();
            while (itemRs.next()) {
                Map<String, Object> item = new HashMap<>();
                item.put("name", itemRs.getString("product_name"));
                item.put("price", itemRs.getDouble("product_price"));
                item.put("image", itemRs.getString("product_image"));
                item.put("quantity", itemRs.getInt("quantity"));
                items.add(item);
            }
            itemRs.close();
            itemStmt.close();
            order.put("items", items);

            orders.add(order);
        }
        orderRs.close();
        orderStmt.close();
        con.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Orders - ShopEasy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f5f7fb; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; flex-wrap: wrap; align-items: center; }
        .logo { color: #ff9900; font-size: 24px; text-decoration: none; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }
        .page-title { margin-bottom: 30px; display: flex; align-items: center; gap: 12px; }
        .page-title i { font-size: 28px; color: #ff9900; }
        .order-card { background: white; border-radius: 16px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); overflow: hidden; }
        .order-header { background: #f8fafc; padding: 15px 20px; display: flex; justify-content: space-between; flex-wrap: wrap; border-bottom: 1px solid #e2e8f0; }
        .order-id { font-weight: 700; }
        .order-date { color: #64748b; font-size: 14px; }
        .order-status { font-weight: 600; }
        .status-confirmed { color: #28a745; }
        .status-cancelled { color: #dc3545; }
        .order-body { padding: 20px; }
        .items-table { width: 100%; border-collapse: collapse; }
        .items-table th, .items-table td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .items-table th { background: #f8fafc; font-weight: 600; }
        .product-info { display: flex; align-items: center; gap: 12px; }
        .product-info img { width: 60px; height: 60px; object-fit: contain; background: #f8fafc; border-radius: 8px; }
        .total-row { text-align: right; margin-top: 15px; font-weight: bold; font-size: 16px; }
        .empty-msg { text-align: center; padding: 60px; background: white; border-radius: 16px; }
        .btn { background: #ff9900; color: white; padding: 8px 20px; text-decoration: none; border-radius: 25px; display: inline-block; margin-top: 15px; }
        @media (max-width: 768px) {
            .items-table, .items-table thead, .items-table tbody, .items-table tr, .items-table td { display: block; }
            .items-table th { display: none; }
            .items-table td { display: flex; justify-content: space-between; align-items: center; border-bottom: none; }
            .product-info { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">🛍️ ShopEasy</a>
        <div class="nav">
            <a href="products.jsp">Products</a>
            <a href="ViewCartServlet">Cart</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>👋 Hi, <%= username %></div>
    </div>

    <div class="container">
        <div class="page-title">
            <i class="fas fa-truck"></i>
            <h2>My Orders</h2>
        </div>

        <% if (orders.isEmpty()) { %>
            <div class="empty-msg">
                <i class="fas fa-box-open" style="font-size: 48px; color: #ccc;"></i>
                <p style="margin: 15px 0;">You haven't placed any orders yet.</p>
                <a href="products.jsp" class="btn">Start Shopping</a>
            </div>
        <% } else {
            for (Map<String, Object> order : orders) {
                List<Map<String, Object>> items = (List<Map<String, Object>>) order.get("items");
                String status = (String) order.get("status");
                String statusClass = "confirmed".equals(status) ? "status-confirmed" : "status-cancelled";
        %>
            <div class="order-card">
                <div class="order-header">
                    <div class="order-id">Order #<%= order.get("orderId") %></div>
                    <div class="order-date"><i class="far fa-calendar-alt"></i> <%= order.get("date") %></div>
                    <div class="order-status <%= statusClass %>"><%= status %></div>
                </div>
                <div class="order-body">
                    <table class="items-table">
                        <thead>
                            <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th></tr>
                        </thead>
                        <tbody>
                        <% for (Map<String, Object> item : items) { 
                            double price = (Double) item.get("price");
                            int qty = (Integer) item.get("quantity");
                            double subtotal = price * qty;
                        %>
                            <tr>
                                <td>
                                    <div class="product-info">
                                        <img src="<%= item.get("image") %>" onerror="this.src='https://placehold.co/60x60/ff9900/white?text=Product'">
                                        <span><%= item.get("name") %></span>
                                    </div>
                                </td>
                                <td>₹<%= String.format("%,.0f", price) %></td>
                                <td><%= qty %></td>
                                <td>₹<%= String.format("%,.0f", subtotal) %></td>
                            </tr>
                        <% } %>
                        </tbody>
                    </table>
                    <div class="total-row">
                        Total Paid: ₹<%= String.format("%,.0f", order.get("total")) %>
                    </div>
                    <div style="margin-top: 15px; text-align: right;">
                        <span class="payment-info">💳 <%= order.get("paymentMethod") %></span>
                    </div>
                </div>
            </div>
        <% } } %>
    </div>
</body>
</html>