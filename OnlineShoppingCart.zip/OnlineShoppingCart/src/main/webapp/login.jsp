<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ShopEasy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>ShopEasy</h1>
            </div>
            <ul class="nav-links">
                <li><a href="index.jsp">Home</a></li>
                <li><a href="login.jsp">Login</a></li>
                <li><a href="register.jsp">Register</a></li>
            </ul>
        </div>
    </nav>

    <div class="form-container">
        <h2>Customer Login</h2>
        
        <% 
            String msg = request.getParameter("msg");
            if("logout".equals(msg)) { 
        %>
            <div class="success-msg" style="background:rgba(16,185,129,0.2); color:#10b981; padding:12px; border-radius:10px; margin-bottom:20px; text-align:center;">
                ✅ You have been logged out successfully!
            </div>
        <% } else if("registered".equals(msg)) { 
            String username = request.getParameter("username");
        %>
            <div class="success-msg" style="background:rgba(16,185,129,0.2); color:#10b981; padding:12px; border-radius:10px; margin-bottom:20px; text-align:center;">
                ✅ Registration Successful! Please login below.
            </div>
        <% } %>
        
        <form action="LoginServlet" method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </form>
        <p class="form-footer">Don't have an account? <a href="register.jsp">Register here</a></p>
        <p class="form-footer"><a href="admin-login.jsp">Admin Login</a></p>
    </div>
</body>
</html>