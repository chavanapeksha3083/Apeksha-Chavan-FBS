<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    String role = (String) session.getAttribute("role");
    if(role == null || !"admin".equals(role)) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    String username = (String) session.getAttribute("username");
    
    // Database connection
    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";
    
    List<Map<String, Object>> users = new ArrayList<>();
    List<Map<String, Object>> products = new ArrayList<>();
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        Statement stmt = con.createStatement();
        
        // Fetch all customers
        ResultSet rs = stmt.executeQuery("SELECT user_id, username, email, full_name, created_at FROM users WHERE role = 'customer' ORDER BY user_id DESC");
        while(rs.next()) {
            Map<String, Object> u = new HashMap<>();
            u.put("id", rs.getInt("user_id"));
            u.put("username", rs.getString("username"));
            u.put("email", rs.getString("email"));
            u.put("fullName", rs.getString("full_name"));
            u.put("createdAt", rs.getTimestamp("created_at"));
            users.add(u);
        }
        rs.close();
        
        // Fetch all products
        rs = stmt.executeQuery("SELECT product_id, name, price, category, quantity FROM products ORDER BY product_id DESC");
        while(rs.next()) {
            Map<String, Object> p = new HashMap<>();
            p.put("id", rs.getInt("product_id"));
            p.put("name", rs.getString("name"));
            p.put("price", rs.getDouble("price"));
            p.put("category", rs.getString("category"));
            p.put("quantity", rs.getInt("quantity"));
            products.add(p);
        }
        rs.close();
        stmt.close();
        con.close();
    } catch(Exception e) {
        e.printStackTrace();
    }
    
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - ShopEasy</title>
    <meta charset="UTF-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial; background: #f0f2f5; padding: 20px; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; flex-wrap: wrap; margin-bottom: 20px; border-radius: 10px; }
        .logo { color: #ff9900; font-size: 24px; font-weight: bold; text-decoration: none; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1400px; margin: auto; }
        .section { background: white; border-radius: 12px; padding: 20px; margin-bottom: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        h2 { margin-bottom: 20px; color: #1a1a2e; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8fafc; }
        .btn-add { background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 6px; display: inline-block; margin-bottom: 15px; }
        .btn-edit { background: #3b82f6; color: white; padding: 4px 12px; text-decoration: none; border-radius: 4px; font-size: 12px; }
        .btn-delete { background: #ef4444; color: white; padding: 4px 12px; text-decoration: none; border-radius: 4px; font-size: 12px; margin-left: 5px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 6px; margin-bottom: 15px; }
        .success-msg { background: #d4edda; color: #155724; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .error-msg { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        @media (max-width: 768px) { table { display: block; overflow-x: auto; } }
    </style>
</head>
<body>
    <div class="header">
        <a href="admin-dashboard.jsp" class="logo">🛍️ ShopEasy Admin</a>
        <div class="nav">
            <a href="add-product.jsp">➕ Add Product</a>
            <a href="ViewOrdersServlet">📦 Orders</a>
            <a href="LogoutServlet">🚪 Logout</a>
        </div>
        <div>👑 Admin: <%= username %></div>
    </div>

    <div class="container">
        <% if("user_deleted".equals(msg)) { %>
            <div class="success">✅ User deleted successfully!</div>
        <% } else if("product_deleted".equals(msg)) { %>
            <div class="success">✅ Product deleted successfully!</div>
        <% } else if("product_added".equals(msg)) { %>
            <div class="success">✅ Product added successfully!</div>
        <% } else if("product_updated".equals(msg)) { %>
            <div class="success">✅ Product updated successfully!</div>
        <% } else if("delete_failed".equals(msg)) { %>
            <div class="error-msg">❌ Product not found or could not be deleted.</div>
        <% } else if("delete_error".equals(msg)) { %>
            <div class="error-msg">❌ Database error – please try again.</div>
        <% } %>

        <!-- Users Section -->
        <div class="section">
            <h2>👥 Registered Customers</h2>
            <table>
                <thead>
                    <tr><th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Registered On</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <% if(users.isEmpty()) { %>
                        <tr><td colspan="6">No users found</td></tr>
                    <% } else {
                        for(Map<String, Object> u : users) { %>
                            <tr>
                                <td><%= u.get("id") %></td>
                                <td><%= u.get("username") %></td>
                                <td><%= u.get("fullName") %></td>
                                <td><%= u.get("email") %></td>
                                <td><%= u.get("createdAt") %></td>
                                <td><a href="DeleteUserServlet?userId=<%= u.get("id") %>" class="btn-delete" onclick="return confirm('Delete this user?')">Delete</a></td>
                            </tr>
                    <% } } %>
                </tbody>
            </table>
        </div>

        <!-- Products Section -->
        <div class="section">
            <h2>🛍️ Products</h2>
            <a href="add-product.jsp" class="btn-add">+ Add New Product</a>
            <table>
                <thead>
                    <tr><th>ID</th><th>Name</th><th>Price</th><th>Category</th><th>Stock</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <% if(products.isEmpty()) { %>
                        <tr><td colspan="6">No products found</td></tr>
                    <% } else {
                        for(Map<String, Object> p : products) { %>
                            <tr>
                                <td><%= p.get("id") %></td>
                                <td><%= p.get("name") %></td>
                                <td>₹<%= String.format("%,.0f", p.get("price")) %></td>
                                <td><%= p.get("category") %></td>
                                <td><%= p.get("quantity") %></td>
                                <td>
                                    <a href="update-product.jsp?id=<%= p.get("id") %>" class="btn-edit">Edit</a>
                                    <a href="DeleteProductServlet?productId=<%= p.get("id") %>" class="btn-delete" onclick="return confirm('Delete this product?')">Delete</a>
                                </td>
                            </tr>
                    <% } } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>