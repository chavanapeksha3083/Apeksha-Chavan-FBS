<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String username = (String) session.getAttribute("username");
    int productId = Integer.parseInt(request.getParameter("id"));

    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";

    String name="", description="", brand="", image="";
    double price=0, mrp=0;
    int stock=0, reviews=0;
    double rating=0;

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        PreparedStatement pst = con.prepareStatement("SELECT * FROM products WHERE product_id=?");
        pst.setInt(1, productId);
        ResultSet rs = pst.executeQuery();
        if(rs.next()) {
            name = rs.getString("name");
            description = rs.getString("description");
            price = rs.getDouble("price");
            mrp = rs.getDouble("mrp");
            brand = rs.getString("brand");
            stock = rs.getInt("quantity");
            image = rs.getString("image_url");
            rating = rs.getDouble("rating");
            reviews = rs.getInt("reviews");
        }
        rs.close();
        pst.close();
        con.close();
    } catch(Exception e) { e.printStackTrace(); }

    // Prepare disabled attribute string (to avoid colon in HTML)
    String disabledAttr = (stock <= 0) ? "disabled" : "";
%>
<!DOCTYPE html>
<html>
<head>
    <title><%= name %> - ShopEasy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: Arial; background:#f5f5f5; }
        .header { background:#1a1a2e; color:white; padding:15px 20px; display:flex; justify-content:space-between; flex-wrap:wrap; }
        .logo { color:#ff9900; font-size:24px; text-decoration:none; }
        .nav a { color:white; margin-left:20px; text-decoration:none; }
        .container { max-width:1200px; margin:20px auto; background:white; padding:30px; border-radius:12px; }
        .product-detail { display:flex; gap:40px; flex-wrap:wrap; }
        .product-image { flex:1; text-align:center; }
        .product-image img { max-width:100%; max-height:400px; object-fit:contain; }
        .product-info { flex:1; }
        .price { font-size:28px; font-weight:bold; color:#b12704; margin:10px 0; }
        .mrp { font-size:16px; color:#999; text-decoration:line-through; margin-left:10px; }
        .stock { margin:10px 0; padding:5px 12px; display:inline-block; border-radius:20px; }
        .in-stock { background:#e8f5e9; color:#28a745; }
        .low-stock { background:#fff3e0; color:#ff9800; }
        .out-stock { background:#ffebee; color:#f44336; }
        .quantity { display:flex; align-items:center; gap:15px; margin:20px 0; }
        .quantity input { width:80px; padding:8px; text-align:center; font-size:16px; }
        .total-price { font-size:20px; font-weight:bold; margin:15px 0; }
        .button-group { display:flex; gap:15px; margin-top:20px; }
        .btn-cart, .btn-buy { flex:1; padding:12px; font-size:16px; font-weight:bold; border:none; border-radius:8px; cursor:pointer; }
        .btn-cart { background:#ffd814; }
        .btn-buy { background:#ff9900; color:white; }
        @media (max-width:768px){ .product-detail{flex-direction:column;} }
    </style>
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">🛍️ ShopEasy</a>
        <div class="nav">
            <a href="ViewCartServlet">Cart</a>
            <a href="MyOrdersServlet">Orders</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Hi, <%= username %></div>
    </div>

    <div class="container">
        <div class="product-detail">
            <div class="product-image">
                <img src="<%= image %>" onerror="this.src='https://placehold.co/400x400/ff9900/white?text=Product'">
            </div>
            <div class="product-info">
                <div class="brand"><%= brand %></div>
                <h1><%= name %></h1>
                <div class="rating">⭐ <%= rating %> (<%= reviews %> reviews)</div>
                <div class="price">
                    ₹<span id="unitPrice"><%= String.format("%,.0f", price) %></span>
                    <span class="mrp">₹<%= String.format("%,.0f", mrp) %></span>
                </div>
                <div class="stock">
                    <% if(stock<=0) { %>
                        <span class="out-stock">Out of Stock</span>
                    <% } else if(stock<=5) { %>
                        <span class="low-stock">Only <%= stock %> left!</span>
                    <% } else { %>
                        <span class="in-stock">In Stock</span>
                    <% } %>
                </div>
                <p><%= description %></p>

                <div class="quantity">
                    <label>Quantity:</label>
                    <input type="number" id="qty" value="1" min="1" max="<%= stock %>" <%= disabledAttr %>>
                </div>
                <div class="total-price" id="totalPrice">Total: ₹<%= String.format("%,.0f", price) %></div>

                <div class="button-group">
                    <form action="AddToCartServlet" method="post" style="flex:1">
                        <input type="hidden" name="productId" value="<%= productId %>">
                        <input type="hidden" name="quantity" id="cartQty" value="1">
                        <button type="submit" class="btn-cart" <%= disabledAttr %> onclick="document.getElementById('cartQty').value=document.getElementById('qty').value">🛒 Add to Cart</button>
                    </form>
                    <button class="btn-buy" <%= disabledAttr %> onclick="buyNow()">⚡ Buy Now</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let unitPrice = <%= price %>;
        let maxStock = <%= stock %>;

        function updateTotal() {
            let qty = document.getElementById('qty').value;
            if(qty < 1) qty = 1;
            if(qty > maxStock) qty = maxStock;
            let total = unitPrice * qty;
            document.getElementById('totalPrice').innerHTML = 'Total: ₹' + total.toLocaleString('en-IN');
        }

        function buyNow() {
            let qty = document.getElementById('qty').value;
            window.location.href = 'BuyNowServlet?productId=<%= productId %>&quantity=' + qty;
        }

        document.getElementById('qty').addEventListener('input', updateTotal);
        updateTotal();
    </script>
</body>
</html>