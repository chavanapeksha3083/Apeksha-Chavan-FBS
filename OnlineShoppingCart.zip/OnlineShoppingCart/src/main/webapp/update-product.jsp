<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*" %>
<%
    if(session == null || !"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    int productId = Integer.parseInt(request.getParameter("id"));
    
    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";
    
    String name = "", description = "", category = "", imageUrl = "";
    double price = 0;
    int quantity = 0;
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        PreparedStatement pst = con.prepareStatement("SELECT * FROM products WHERE product_id = ?");
        pst.setInt(1, productId);
        ResultSet rs = pst.executeQuery();
        if(rs.next()) {
            name = rs.getString("name");
            description = rs.getString("description");
            price = rs.getDouble("price");
            category = rs.getString("category");
            quantity = rs.getInt("quantity");
            imageUrl = rs.getString("image_url");
        } else {
            response.sendRedirect("admin-dashboard.jsp");
            return;
        }
        rs.close();
        pst.close();
        con.close();
    } catch(Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Update Product - ShopEasy Admin</title>
    <meta charset="UTF-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial; background: #f0f2f5; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; flex-wrap: wrap; }
        .logo { color: #ff9900; font-size: 24px; text-decoration: none; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 25px; color: #1a1a2e; }
        label { font-weight: 600; display: block; margin-top: 15px; margin-bottom: 5px; }
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        button { background: #ff9900; color: white; padding: 12px; border: none; border-radius: 6px; cursor: pointer; width: 100%; margin-top: 20px; font-size: 16px; font-weight: bold; }
        button:hover { background: #e68a00; }
        .cancel { display: block; text-align: center; margin-top: 15px; color: #666; text-decoration: none; }
    </style>
</head>
<body>
    <div class="header">
        <a href="admin-dashboard.jsp" class="logo">🛍️ ShopEasy Admin</a>
        <div class="nav">
            <a href="admin-dashboard.jsp">Dashboard</a>
            <a href="add-product.jsp">Add Product</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>👑 Admin</div>
    </div>

    <div class="container">
        <h2>✏️ Update Product</h2>
        <form action="UpdateProductServlet" method="post">
            <input type="hidden" name="productId" value="<%= productId %>">
            
            <label>Product Name</label>
            <input type="text" name="name" value="<%= name %>" required>
            
            <label>Description</label>
            <textarea name="description" rows="3" required><%= description %></textarea>
            
            <label>Price (₹)</label>
            <input type="number" name="price" step="0.01" value="<%= price %>" required>
            
            <label>Category</label>
            <select name="category" required>
                <option value="Electronics" <%= category.equals("Electronics") ? "selected" : "" %>>📱 Electronics</option>
                <option value="Footwear" <%= category.equals("Footwear") ? "selected" : "" %>>👟 Footwear</option>
                <option value="Clothing" <%= category.equals("Clothing") ? "selected" : "" %>>👕 Clothing</option>
                <option value="Audio" <%= category.equals("Audio") ? "selected" : "" %>>🎧 Audio</option>
                <option value="Wearables" <%= category.equals("Wearables") ? "selected" : "" %>>⌚ Wearables</option>
                <option value="Cosmetics" <%= category.equals("Cosmetics") ? "selected" : "" %>>💄 Cosmetics</option>
                <option value="Jewelry" <%= category.equals("Jewelry") ? "selected" : "" %>>💍 Jewelry</option>
                <option value="Home & Kitchen" <%= category.equals("Home & Kitchen") ? "selected" : "" %>>🏠 Home & Kitchen</option>
                <option value="Sports" <%= category.equals("Sports") ? "selected" : "" %>>⚽ Sports</option>
                <option value="Books" <%= category.equals("Books") ? "selected" : "" %>>📚 Books</option>
            </select>
            
            <label>Quantity</label>
            <input type="number" name="quantity" value="<%= quantity %>" required>
            
            <label>Image URL</label>
            <input type="text" name="imageUrl" value="<%= imageUrl != null ? imageUrl : "" %>" placeholder="https://...">
            
            <button type="submit">💾 Update Product</button>
            <a href="admin-dashboard.jsp" class="cancel">← Cancel</a>
        </form>
    </div>
</body>
</html>