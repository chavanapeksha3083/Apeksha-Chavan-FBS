<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List, com.bean.CartItem" %>
<%
  
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");
    Double cartTotal = (Double) session.getAttribute("cartTotal");
    if(cartItems == null || cartItems.isEmpty()) {
        response.sendRedirect("ViewCartServlet");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - ShopEasy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>ShopEasy</h1>
            </div>
            <ul class="nav-links">
                <li><a href="ProductServlet">Products</a></li>
                <li><a href="ViewCartServlet">Cart</a></li>
                <li><a href="LogoutServlet">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="payment-container">
            <div class="payment-header">
                <h2>Secure Payment</h2>
                <p>Enter your card details to complete the purchase</p>
            </div>
            
            <div class="payment-amount">
                <h3>Total Amount: $<%= String.format("%.2f", cartTotal) %></h3>
            </div>
            
            <form action="PaymentServlet" method="post" class="payment-form" onsubmit="return validatePayment()">
                <div class="form-group">
                    <label>Cardholder Name</label>
                    <input type="text" name="cardHolderName" id="cardHolderName" placeholder="Name on card" required>
                </div>
                
                <div class="form-group">
                    <label>Card Number</label>
                    <input type="text" name="cardNumber" id="cardNumber" placeholder="1234 5678 9012 3456" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <input type="text" name="expiryDate" id="expiryDate" placeholder="MM/YY" required>
                    </div>
                    <div class="form-group">
                        <label>CVV</label>
                        <input type="password" name="cvv" id="cvv" placeholder="123" required>
                    </div>
                </div>
                
                <div class="secure-badge">
                    <span>🔒 Secure Payment</span>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Complete Payment</button>
            </form>
        </div>
    </div>
</body>
</html>