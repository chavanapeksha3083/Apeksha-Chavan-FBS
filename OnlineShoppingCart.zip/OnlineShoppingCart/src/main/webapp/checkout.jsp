<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    String username = (String) session.getAttribute("username");
    List<Map<String, Object>> cartItems = (List<Map<String, Object>>) session.getAttribute("cartItems");
    Double cartTotal = (Double) session.getAttribute("cartTotal");
    if(cartTotal == null) cartTotal = 0.0;
%>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout - ShopEasy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f5f7fb;
        }
        
        .header {
            background: #1a1a2e;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo { font-size: 24px; font-weight: bold; color: #ff9900; text-decoration: none; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .checkout-container {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
        }
        
        .shipping-form, .order-summary, .payment-methods {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
        }
        
        h3 { margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        
        .payment-option {
            display: flex;
            align-items: center;
            padding: 15px;
            border: 1px solid #eee;
            border-radius: 10px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-option:hover { background: #f8f9fa; }
        .payment-option input { margin-right: 15px; transform: scale(1.2); }
        .payment-option i { font-size: 24px; margin-right: 15px; }
        
        .order-item {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
        }
        .total-row {
            border-top: 2px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
            font-weight: bold;
            font-size: 18px;
        }
        .btn-place-order {
            width: 100%;
            background: #ff9900;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) {
            .checkout-container { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">🛍️ ShopEasy</a>
        <div class="nav">
            <a href="ViewCartServlet">← Back to Cart</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>👋 Hi, <%= username %></div>
    </div>

    <div class="container">
        <h2>Checkout</h2>
        
        <div class="checkout-container">
            <div>
                <div class="shipping-form">
                    <h3>📦 Shipping Address</h3>
                    <form action="PlaceOrderServlet" method="post" id="orderForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="firstName" required>
                            </div>
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" name="lastName" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="address" placeholder="House No, Street, Area" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" required>
                            </div>
                            <div class="form-group">
                                <label>Pincode</label>
                                <input type="text" name="pincode" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="tel" name="phone" required>
                        </div>
                </div>
                
                <div class="payment-methods">
                    <h3>💳 Payment Method</h3>
                    
                    <label class="payment-option">
                        <input type="radio" name="paymentMethod" value="COD" checked>
                        <i class="fas fa-truck"></i>
                        <div>
                            <strong>Cash on Delivery (COD)</strong>
                            <p style="font-size: 12px; color: #666;">Pay when you receive the product</p>
                        </div>
                    </label>
                    
                    <label class="payment-option">
                        <input type="radio" name="paymentMethod" value="Card">
                        <i class="fas fa-credit-card"></i>
                        <div>
                            <strong>Credit/Debit Card</strong>
                            <p style="font-size: 12px; color: #666;">Visa, Mastercard, RuPay</p>
                        </div>
                    </label>
                    
                    <label class="payment-option">
                        <input type="radio" name="paymentMethod" value="UPI">
                        <i class="fas fa-mobile-alt"></i>
                        <div>
                            <strong>UPI / GPay / PhonePe</strong>
                            <p style="font-size: 12px; color: #666;">Google Pay, PhonePe, Paytm</p>
                        </div>
                    </label>
                    
                    <label class="payment-option">
                        <input type="radio" name="paymentMethod" value="NetBanking">
                        <i class="fas fa-university"></i>
                        <div>
                            <strong>Net Banking</strong>
                            <p style="font-size: 12px; color: #666;">All major banks</p>
                        </div>
                    </label>
                    </form>
                </div>
            </div>
            
            <div>
                <div class="order-summary">
                    <h3>🛒 Order Summary</h3>
                    <% if(cartItems != null) {
                        for(Map<String, Object> item : cartItems) { %>
                            <div class="order-item">
                                <span><%= item.get("name") %> x <%= item.get("quantity") %></span>
                                <span>₹<%= String.format("%,.0f", item.get("subtotal")) %></span>
                            </div>
                    <% } } %>
                    <div class="order-item">
                        <span>Shipping</span>
                        <span style="color: #28a745;">Free</span>
                    </div>
                    <div class="order-item total-row">
                        <span>Total Amount</span>
                        <span style="color: #b12704;">₹<%= String.format("%,.0f", cartTotal) %></span>
                    </div>
                    <button type="submit" form="orderForm" class="btn-place-order">
                        <i class="fas fa-check-circle"></i> Place Order
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>