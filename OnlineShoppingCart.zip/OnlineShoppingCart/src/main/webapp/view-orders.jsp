<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    List<Map<String, Object>> orders = (List<Map<String, Object>>) session.getAttribute("allOrders");
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
    <title>View Orders - ShopEasy Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; }
        .logo { color: #ff9900; text-decoration: none; font-size: 24px; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 16px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8fafc; }
        .status-confirmed { color: #28a745; font-weight: bold; }
        .status-cancelled { color: #dc3545; }
        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 12px;
        }
        .btn-delete:hover { background: #c82333; }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="admin-dashboard.jsp" class="logo">ShopEasy Admin</a>
        <div class="nav">
            <a href="admin-dashboard.jsp">Dashboard</a>
            <a href="add-product.jsp">Add Product</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Admin Panel</div>
    </div>

    <div class="container">
        <h2>All Customer Orders</h2>

        <!-- ✅ Delete Success/Error Message Block (added as requested) -->
        <% if("deleted".equals(msg)) { %>
            <div class="success">✅ Order deleted successfully!</div>
        <% } else if("error".equals(msg)) { %>
            <div class="error">❌ Failed to delete order!</div>
        <% } %>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <% if(orders != null) {
                    for(Map<String, Object> order : orders) { %>
                        <tr>
                            <td>#<%= order.get("orderId") %></td>
                            <td><%= order.get("username") %></td>
                            <td>₹<%= String.format("%,.0f", order.get("total")) %></td>
                            <td><%= order.get("paymentMethod") %></td>
                            <td class="<%= "confirmed".equals(order.get("status")) ? "status-confirmed" : "status-cancelled" %>"><%= order.get("status") %></td>
                            <td><%= order.get("date") %></td>
                            <td>
                                <a href="DeleteOrderServlet?orderId=<%= order.get("orderId") %>" 
                                   class="btn-delete" 
                                   onclick="return confirm('Are you sure you want to permanently delete this order?')">
                                   Delete
                                </a>
                            </td>
                        </tr>
                    <% }
                } %>
            </tbody>
        </table>
    </div>
</body>
</html>