<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    String username = (String) session.getAttribute("username");
    int userId = (Integer) session.getAttribute("userId");
    
    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";
    
    String selectedCategory = request.getParameter("category");
    if(selectedCategory == null) selectedCategory = "all";
    
    List<Map<String, Object>> products = new ArrayList<>();
    Set<Integer> wishlistIds = new HashSet<>();
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        
        String query;
        PreparedStatement pst;
        if(selectedCategory.equals("all")) {
            query = "SELECT * FROM products WHERE quantity > 0 ORDER BY product_id DESC";
            pst = con.prepareStatement(query);
        } else {
            query = "SELECT * FROM products WHERE category = ? AND quantity > 0 ORDER BY product_id DESC";
            pst = con.prepareStatement(query);
            pst.setString(1, selectedCategory);
        }
        
        ResultSet rs = pst.executeQuery();
        while(rs.next()) {
            Map<String, Object> product = new HashMap<>();
            product.put("id", rs.getInt("product_id"));
            product.put("name", rs.getString("name"));
            product.put("price", rs.getDouble("price"));
            product.put("mrp", rs.getDouble("mrp"));
            product.put("category", rs.getString("category"));
            product.put("brand", rs.getString("brand"));
            product.put("rating", rs.getDouble("rating"));
            product.put("reviews", rs.getInt("reviews"));
            product.put("quantity", rs.getInt("quantity"));
            product.put("image", rs.getString("image_url"));
            products.add(product);
        }
        rs.close();
        pst.close();
        
        // Get wishlist
        String wishQuery = "SELECT product_id FROM wishlist WHERE user_id = ?";
        pst = con.prepareStatement(wishQuery);
        pst.setInt(1, userId);
        rs = pst.executeQuery();
        while(rs.next()) {
            wishlistIds.add(rs.getInt("product_id"));
        }
        rs.close();
        pst.close();
        con.close();
    } catch(Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Products - ShopEasy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial; background: #f5f5f5; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; flex-wrap: wrap; }
        .logo { color: #ff9900; font-size: 24px; text-decoration: none; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1400px; margin: 20px auto; padding: 0 20px; }
        .categories { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px; justify-content: center; }
        .category { background: white; padding: 8px 20px; border-radius: 30px; text-decoration: none; color: #333; border: 1px solid #ddd; font-size: 14px; transition: 0.3s; }
        .category:hover { background: #ff9900; color: white; border-color: #ff9900; }
        .category.active { background: #ff9900; color: white; border-color: #ff9900; }
        .product-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .product-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            padding: 15px;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            transition: 0.3s;
            position: relative;
        }
        .product-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .product-card img { width: 100%; height: 180px; object-fit: contain; }
        .product-card h3 { font-size: 16px; margin: 10px 0; }
        .price { font-size: 18px; font-weight: bold; color: #b12704; }
        .btn { background: #ffd814; border: none; padding: 8px 15px; border-radius: 20px; cursor: pointer; margin-top: 10px; width: 100%; font-weight: bold; }
        .btn:hover { background: #f7ca00; }
        
        .wishlist-btn {
            position: absolute;
            top: 12px;
            right: 12px;
            background: white;
            border-radius: 50%;
            width: 34px;
            height: 34px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            z-index: 2;
        }
        .wishlist-btn i { font-size: 18px; }
        .wishlist-active { color: #ff4444; }
        .wishlist-inactive { color: #888; }
        
        @media (max-width: 1024px) { .product-grid { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 768px) { .product-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 500px) { .product-grid { grid-template-columns: 1fr; } }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">🛍️ ShopEasy</a>
        <div class="nav">
            <a href="ViewCartServlet">Cart</a>
            <a href="MyOrdersServlet">Orders</a>
            <a href="wishlist.jsp">Wishlist</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Hi, <%= username %></div>
    </div>

    <div class="container">
        <div class="categories">
            <a href="products.jsp?category=all" class="category <%= selectedCategory.equals("all") ? "active" : "" %>">All</a>
            <a href="products.jsp?category=Electronics" class="category <%= selectedCategory.equals("Electronics") ? "active" : "" %>">📱 Electronics</a>
            <a href="products.jsp?category=Footwear" class="category <%= selectedCategory.equals("Footwear") ? "active" : "" %>">👟 Footwear</a>
            <a href="products.jsp?category=Clothing" class="category <%= selectedCategory.equals("Clothing") ? "active" : "" %>">👕 Clothing</a>
            <a href="products.jsp?category=Audio" class="category <%= selectedCategory.equals("Audio") ? "active" : "" %>">🎧 Audio</a>
            <a href="products.jsp?category=Wearables" class="category <%= selectedCategory.equals("Wearables") ? "active" : "" %>">⌚ Wearables</a>
            <a href="products.jsp?category=Cosmetics" class="category <%= selectedCategory.equals("Cosmetics") ? "active" : "" %>">💄 Cosmetics</a>
            <a href="products.jsp?category=Jewelry" class="category <%= selectedCategory.equals("Jewelry") ? "active" : "" %>">💍 Jewelry</a>
          
            <a href="products.jsp?category=Home%20%26%20Kitchen" class="category <%= selectedCategory.equals("Home & Kitchen") ? "active" : "" %>">🏠 Home & Kitchen</a>
            <a href="products.jsp?category=Sports" class="category <%= selectedCategory.equals("Sports") ? "active" : "" %>">⚽ Sports</a>
            <a href="products.jsp?category=Books" class="category <%= selectedCategory.equals("Books") ? "active" : "" %>">📚 Books</a>
        </div>

        <div class="product-grid">
            <% if(products.isEmpty()) { %>
                <div style="grid-column:1/-1; text-align:center; padding:50px;">No products found in this category.</div>
            <% } else {
                for(Map<String, Object> p : products) { 
                    int pid = (Integer) p.get("id");
                    double price = (Double) p.get("price");
                    String img = (String) p.get("image");
                    if(img == null || img.isEmpty()) img = "https://placehold.co/300x200/ff9900/white?text=Product";
                    boolean inWishlist = wishlistIds.contains(pid);
            %>
                <div class="product-card">
                    <!-- Wishlist button -->
                    <a href="WishlistServlet?productId=<%= pid %>" class="wishlist-btn">
                        <i class="<%= inWishlist ? "fas fa-heart wishlist-active" : "far fa-heart wishlist-inactive" %>"></i>
                    </a>
                    <!-- Product image and details (with fallback) -->
                    <a href="product-detail.jsp?id=<%= pid %>" style="text-decoration: none; color: inherit;">
                        <img src="<%= img %>" 
                             onerror="this.src='https://picsum.photos/id/20/300/200'"
                             alt="<%= p.get("name") %>">
                        <h3><%= p.get("name") %></h3>
                        <div class="price">₹<%= String.format("%,.0f", price) %></div>
                    </a>
                    <!-- Add to cart form -->
                    <form action="AddToCartServlet" method="post">
                        <input type="hidden" name="productId" value="<%= pid %>">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="btn">🛒 Add to Cart</button>
                    </form>
                </div>
            <% } } %>
        </div>
    </div>
</body>
</html>