<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    if(session == null || !"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Add Product - ShopEasy Admin</title>
    <meta charset="UTF-8">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial; background: #f0f2f5; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; }
        .logo { color: #ff9900; font-size: 24px; text-decoration: none; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 25px; color: #1a1a2e; }
        label { font-weight: 600; display: block; margin-top: 15px; margin-bottom: 5px; }
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        button { background: #ff9900; color: white; padding: 12px; border: none; border-radius: 6px; cursor: pointer; width: 100%; margin-top: 20px; font-size: 16px; font-weight: bold; }
        button:hover { background: #e68a00; }
        .cancel { display: block; text-align: center; margin-top: 15px; color: #666; text-decoration: none; }
    </style>
</head>
<body>
    <div class="header">
        <a href="admin-dashboard.jsp" class="logo">🛍️ ShopEasy Admin</a>
        <div class="nav">
            <a href="admin-dashboard.jsp">Dashboard</a>
            <a href="add-product.jsp">Add Product</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>👑 Admin</div>
    </div>

    <div class="container">
        <h2>➕ Add New Product</h2>
        <form action="AddProductServlet" method="post">
            <label>Product Name</label>
            <input type="text" name="name" required>
            
            <label>Description</label>
            <textarea name="description" rows="3" required></textarea>
            
            <label>Price (₹)</label>
            <input type="number" name="price" step="0.01" required>
            
            <label>Category</label>
            <select name="category" required>
                <option value="Electronics">📱 Electronics</option>
                <option value="Footwear">👟 Footwear</option>
                <option value="Clothing">👕 Clothing</option>
                <option value="Audio">🎧 Audio</option>
                <option value="Wearables">⌚ Wearables</option>
                <option value="Cosmetics">💄 Cosmetics</option>
                <option value="Jewelry">💍 Jewelry</option>
                <option value="Home & Kitchen">🏠 Home & Kitchen</option>
                <option value="Sports">⚽ Sports</option>
                <option value="Books">📚 Books</option>
            </select>
            
            <label>Quantity</label>
            <input type="number" name="quantity" required>
            
            <label>Image URL</label>
            <input type="text" name="imageUrl" placeholder="https://example.com/image.jpg">
            
            <button type="submit">✨ Add Product</button>
            <a href="admin-dashboard.jsp" class="cancel">← Cancel</a>
        </form>
    </div>
</body>
</html>