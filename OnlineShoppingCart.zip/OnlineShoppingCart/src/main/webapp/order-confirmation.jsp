<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    Boolean orderSuccess = (Boolean) session.getAttribute("orderSuccess");
    String paymentMethod = (String) session.getAttribute("paymentMethod");
    
    if(orderSuccess == null || !orderSuccess) {
        response.sendRedirect("products.jsp");
        return;
    }
    session.removeAttribute("orderSuccess");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Order Confirmation - ShopEasy</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .confirmation-card {
            background: white;
            padding: 50px;
            border-radius: 20px;
            text-align: center;
            max-width: 500px;
            margin: 20px;
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background: #28a745;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        .success-icon i { font-size: 40px; color: white; }
        h2 { color: #28a745; margin-bottom: 10px; }
        .payment-info { 
            background: #f8f9fa; 
            padding: 15px; 
            border-radius: 10px; 
            margin: 20px 0;
        }
        .btn { 
            display: inline-block; 
            background: #ff9900; 
            color: white; 
            padding: 12px 25px; 
            text-decoration: none; 
            border-radius: 25px;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="confirmation-card">
        <div class="success-icon">
            <i class="fas fa-check"></i>
        </div>
        <h2>🎉 Order Placed Successfully!</h2>
        
        <div class="payment-info">
            <p><strong>Payment Method:</strong> <%= paymentMethod %></p>
            <% if("COD".equals(paymentMethod)) { %>
                <p style="color: #28a745; margin-top: 10px;">💵 Pay ₹<%= session.getAttribute("cartTotal") %> when you receive the product</p>
            <% } else { %>
                <p style="color: #28a745;">✅ Payment successful! Your order has been confirmed.</p>
            <% } %>
        </div>
        
        <p>Thank you for shopping with ShopEasy!</p>
        <p>Order confirmation has been sent to your email.</p>
        
        <div style="margin-top: 30px;">
            <a href="MyOrdersServlet" class="btn">📦 View My Orders</a>
            <a href="products.jsp" class="btn">🛍️ Continue Shopping</a>
        </div>
    </div>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</body>
</html>