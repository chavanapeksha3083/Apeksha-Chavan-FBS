<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - ShopEasy</title>
    <link rel="stylesheet" href="style.css">
    <script>
    function validateRegistration() {
        var fullName = document.getElementById("fullName").value;
        var email = document.getElementById("email").value;
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirmPassword").value;
        
        if(fullName.trim() === "") {
            alert("Please enter full name");
            return false;
        }
        
        if(email.trim() === "") {
            alert("Please enter email");
            return false;
        }
        
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!emailPattern.test(email)) {
            alert("Please enter a valid email address");
            return false;
        }
        
        if(username.trim() === "") {
            alert("Please enter username");
            return false;
        }
        
        if(username.length < 3) {
            alert("Username must be at least 3 characters");
            return false;
        }
        
        if(password.length < 6) {
            alert("Password must be at least 6 characters");
            return false;
        }
        
        if(password !== confirmPassword) {
            alert("Passwords do not match");
            return false;
        }
        
        return true;
    }
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>ShopEasy</h1>
            </div>
            <ul class="nav-links">
                <li><a href="index.jsp">Home</a></li>
                <li><a href="login.jsp">Login</a></li>
                <li><a href="register.jsp">Register</a></li>
            </ul>
        </div>
    </nav>

    <div class="form-container">
        <h2>Create Account</h2>
        <form action="RegisterServlet" method="post" onsubmit="return validateRegistration()">
            <div class="form-group">
                <input type="text" name="fullName" id="fullName" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" id="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="text" name="username" id="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="password" id="confirmPassword" placeholder="Confirm Password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Register</button>
        </form>
        <p class="form-footer">Already have an account? <a href="login.jsp">Login here</a></p>
    </div>
</body>
</html>