<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String username = (String) session.getAttribute("username");
    int userId = (Integer) session.getAttribute("userId");

    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";

    List<Map<String, Object>> wishlist = new ArrayList<>();
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        PreparedStatement pst = con.prepareStatement(
            "SELECT p.* FROM products p JOIN wishlist w ON p.product_id = w.product_id WHERE w.user_id = ?");
        pst.setInt(1, userId);
        ResultSet rs = pst.executeQuery();
        while(rs.next()) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", rs.getInt("product_id"));
            item.put("name", rs.getString("name"));
            item.put("price", rs.getDouble("price"));
            item.put("mrp", rs.getDouble("mrp"));
            item.put("image", rs.getString("image_url"));
            wishlist.add(item);
        }
        rs.close();
        pst.close();
        con.close();
    } catch(Exception e) { e.printStackTrace(); }
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Wishlist</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: Arial; background:#f5f5f5; }
        .header { background:#1a1a2e; color:white; padding:15px 20px; display:flex; justify-content:space-between; }
        .logo { color:#ff9900; font-size:24px; text-decoration:none; }
        .nav a { color:white; margin-left:20px; text-decoration:none; }
        .container { max-width:1200px; margin:20px auto; padding:20px; background:white; border-radius:10px; }
        .wishlist-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
        .product-card { border:1px solid #ddd; border-radius:10px; padding:15px; text-align:center; }
        .product-card img { width:100%; height:150px; object-fit:contain; }
        .price { font-size:18px; font-weight:bold; color:#b12704; }
        .btn { background:#ffd814; border:none; padding:8px 15px; border-radius:20px; cursor:pointer; margin-top:10px; }
        .remove { background:#ef4444; color:white; margin-left:5px; }
        @media (max-width:768px){ .wishlist-grid{grid-template-columns:repeat(2,1fr);} }
    </style>
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">ShopEasy</a>
        <div class="nav">
            <a href="products.jsp">Products</a>
            <a href="ViewCartServlet">Cart</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Hi, <%= username %></div>
    </div>

    <div class="container">
        <h2>❤️ My Wishlist</h2>
        <% if(wishlist.isEmpty()) { %>
            <p>No items in wishlist.</p>
        <% } else { %>
            <div class="wishlist-grid">
                <% for(Map<String,Object> item : wishlist) { %>
                    <div class="product-card">
                        <a href="product-detail.jsp?id=<%= item.get("id") %>">
                            <img src="<%= item.get("image") %>" onerror="this.src='https://placehold.co/300x200/ff9900/white?text=Product'">
                            <h3><%= item.get("name") %></h3>
                            <div class="price">₹<%= String.format("%,.0f", item.get("price")) %></div>
                        </a>
                        <form action="AddToCartServlet" method="post" style="display:inline-block;">
                            <input type="hidden" name="productId" value="<%= item.get("id") %>">
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit" class="btn">Add to Cart</button>
                        </form>
                        <a href="WishlistServlet?productId=<%= item.get("id") %>" class="btn remove">Remove</a>
                    </div>
                <% } %>
            </div>
        <% } %>
    </div>
</body>
</html>