function validateRegistration() {
    var fullName = document.getElementById("fullName").value;
    var email = document.getElementById("email").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    
    if(fullName.trim() === "") {
        alert("Please enter full name");
        return false;
    }
    
    if(email.trim() === "") {
        alert("Please enter email");
        return false;
    }
    
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailPattern.test(email)) {
        alert("Please enter a valid email address");
        return false;
    }
    
    if(username.trim() === "") {
        alert("Please enter username");
        return false;
    }
    
    if(username.length < 3) {
        alert("Username must be at least 3 characters");
        return false;
    }
    
    if(password.length < 6) {
        alert("Password must be at least 6 characters");
        return false;
    }
    
    if(password !== confirmPassword) {
        alert("Passwords do not match");
        return false;
    }
    
    return true;
}

function validatePayment() {
    var cardHolderName = document.getElementById("cardHolderName").value;
    var cardNumber = document.getElementById("cardNumber").value;
    var expiryDate = document.getElementById("expiryDate").value;
    var cvv = document.getElementById("cvv").value;
    
    if(cardHolderName.trim() === "") {
        alert("Please enter cardholder name");
        return false;
    }
    
    var cardNumberPattern = /^\d{16}$|^\d{4}\s\d{4}\s\d{4}\s\d{4}$/;
    var cleanedCardNumber = cardNumber.replace(/\s/g, '');
    if(!/^\d{16}$/.test(cleanedCardNumber)) {
        alert("Please enter a valid 16-digit card number");
        return false;
    }
    
    var expiryPattern = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
    if(!expiryPattern.test(expiryDate)) {
        alert("Please enter valid expiry date (MM/YY)");
        return false;
    }
    
    if(!/^\d{3}$/.test(cvv)) {
        alert("Please enter valid 3-digit CVV");
        return false;
    }
    
    return true;
}