<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    List<Map<String, Object>> users = (List<Map<String, Object>>) session.getAttribute("users");
%>
<!DOCTYPE html>
<html>
<head>
    <title>View Users - ShopEasy Admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f0f2f5;
        }
        
        .header {
            background: #1a1a2e;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .logo { color: #ff9900; text-decoration: none; font-size: 24px; font-weight: bold; }
        .nav a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 16px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8fafc; }
    </style>
</head>
<body>
    <div class="header">
        <a href="admin-dashboard.jsp" class="logo">ShopEasy Admin</a>
        <div class="nav">
            <a href="admin-dashboard.jsp">Dashboard</a>
            <a href="add-product.jsp">Add Product</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Admin Panel</div>
    </div>

    <div class="container">
        <h2>Registered Customers</h2>
        <table>
            <thead>
                <tr><th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Registered On</th></tr>
            </thead>
            <tbody>
                <% if(users != null) {
                    for(Map<String, Object> user : users) { %>
                        <tr><td><%= user.get("userId") %></td><td><%= user.get("username") %></td><td><%= user.get("fullName") %></td><td><%= user.get("email") %></td><td><%= user.get("createdAt") %></td></tr>
                    <% }
                } %>
            </tbody>
        </table>
    </div>
</body>
</html>