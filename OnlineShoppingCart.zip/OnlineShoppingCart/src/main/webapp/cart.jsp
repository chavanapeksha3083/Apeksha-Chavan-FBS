<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*" %>
<%
    if(session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    String username = (String) session.getAttribute("username");
    List<Map<String, Object>> cartItems = (List<Map<String, Object>>) session.getAttribute("cartItems");
    Double cartTotal = (Double) session.getAttribute("cartTotal");
    if(cartTotal == null) cartTotal = 0.0;
%>
<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart - ShopEasy</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .header { background: #1a1a2e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; }
        .logo { color: #ff9900; text-decoration: none; font-size: 24px; font-weight: bold; }
        .nav a { color: white; margin-left: 20px; text-decoration: none; }
        .container { max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; vertical-align: middle; }
        th { background: #f8f8f8; }
        .product-cell {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .product-cell img {
            width: 60px;
            height: 60px;
            object-fit: contain;
        }
        .product-name {
            font-weight: normal;
        }
        .remove-btn { background: #ff4444; color: white; padding: 5px 10px; text-decoration: none; border-radius: 5px; }
        .checkout-btn { background: #ff9900; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px; }
        .total { font-size: 20px; font-weight: bold; text-align: right; margin-top: 20px; }
        .empty { text-align: center; padding: 50px; }
        @media (max-width: 768px) {
            .product-cell { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="products.jsp" class="logo">ShopEasy</a>
        <div class="nav">
            <a href="products.jsp">Products</a>
            <a href="MyOrdersServlet">My Orders</a>
            <a href="LogoutServlet">Logout</a>
        </div>
        <div>Hi, <%= username %></div>
    </div>

    <div class="container">
        <h2>Shopping Cart</h2>
        
        <% if(cartItems == null || cartItems.isEmpty()) { %>
            <div class="empty">
                <p>Your cart is empty!</p>
                <a href="products.jsp" class="checkout-btn">Continue Shopping</a>
            </div>
        <% } else { %>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <% for(Map<String, Object> item : cartItems) { 
                    String img = (String) item.get("image");
                    if(img == null || img.isEmpty()) img = "https://placehold.co/60x60/ff9900/white?text=Product";
                %>
                    <tr>
                        <td>
                            <div class="product-cell">
                                <img src="<%= img %>" alt="<%= item.get("name") %>">
                                <span class="product-name"><%= item.get("name") %></span>
                            </div>
                        </td>
                        <td>₹<%= String.format("%,.0f", item.get("price")) %></td>
                        <td><%= item.get("quantity") %></td>
                        <td>₹<%= String.format("%,.0f", item.get("subtotal")) %></td>
                        <td><a href="RemoveFromCartServlet?cartId=<%= item.get("cartId") %>" class="remove-btn" onclick="return confirm('Remove item?')">Remove</a></td>
                    </tr>
                <% } %>
                </tbody>
            </table>
            <div class="total">Total: ₹<%= String.format("%,.0f", cartTotal) %></div>
            <div style="text-align: right;">
                <a href="products.jsp" class="checkout-btn" style="background: #666;">Continue Shopping</a>
                <a href="checkout.jsp" class="checkout-btn">Proceed to Checkout</a>
            </div>
        <% } %>
    </div>
</body>
</html>