<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*, java.util.*" %>
<%
    if(session == null || session.getAttribute("role") == null || !"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("admin-login.jsp");
        return;
    }
    
    String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    String DB_USER = "root";
    String DB_PASSWORD = "Apeksha@30";
    
    List<Map<String, Object>> orders = new ArrayList<>();
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.user_id ORDER BY o.order_id DESC");
        while(rs.next()) {
            Map<String, Object> order = new HashMap<>();
            order.put("orderId", rs.getInt("order_id"));
            order.put("userId", rs.getInt("user_id"));
            order.put("username", rs.getString("username"));
            order.put("total", rs.getDouble("total_amount"));
            order.put("status", rs.getString("status"));
            order.put("paymentMethod", rs.getString("payment_method"));
            order.put("date", rs.getTimestamp("order_date"));
            orders.add(order);
        }
        con.close();
    } catch(Exception e) { e.printStackTrace(); }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders - Admin</title>
    <style>
        body { font-family: Arial; background: #f0f2f5; margin: 0; padding: 20px; }
        .header { background: #1a1a2e; color: white; padding: 15px; display: flex; justify-content: space-between; }
        .container { max-width: 1200px; margin: 20px auto; background: white; padding: 20px; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; }
        select, button { padding: 5px 10px; margin: 2px; }
        .btn-delete { background: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer; }
        .btn-update { background: #28a745; color: white; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="header">
        <h2>Admin - Orders Management</h2>
        <div><a href="admin-dashboard.jsp" style="color:#ff9900;">Back to Dashboard</a></div>
    </div>
    <div class="container">
        <h3>All Customer Orders</h3>
        <table>
            <thead>
                <tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Action</th></tr>
            </thead>
            <tbody>
                <% for(Map<String,Object> order : orders) { 
                    String status = (String) order.get("status");
                %>
                <tr>
                    <td><%= order.get("orderId") %></td>
                    <td><%= order.get("username") %></td>
                    <td>₹<%= String.format("%,.0f", order.get("total")) %></td>
                    <td><%= order.get("paymentMethod") %></td>
                    <td>
                        <form action="UpdateOrderStatusServlet" method="post" style="display: inline;">
                            <input type="hidden" name="orderId" value="<%= order.get("orderId") %>">
                            <select name="status">
                                <option value="pending" <%= status.equals("pending") ? "selected" : "" %>>Pending</option>
                                <option value="confirmed" <%= status.equals("confirmed") ? "selected" : "" %>>Confirmed</option>
                                <option value="shipped" <%= status.equals("shipped") ? "selected" : "" %>>Shipped</option>
                                <option value="delivered" <%= status.equals("delivered") ? "selected" : "" %>>Delivered</option>
                                <option value="cancelled" <%= status.equals("cancelled") ? "selected" : "" %>>Cancelled</option>
                            </select>
                            <button type="submit" class="btn-update">Update</button>
                        </form>
                    </td>
                    <td><%= order.get("date") %></td>
                    <td>
                        <a href="DeleteOrderServlet?orderId=<%= order.get("orderId") %>" class="btn-delete" onclick="return confirm('Delete this order permanently?')">Delete</a>
                    </td>
                </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</body>
</html>