package aspect.provider;

import DAOInterface.DAOInterface;
import serviceInterface.ShoppingServiceInterface;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ObjectProvider {
    
    static Properties p;
    
    static {
        try {
            p = new Properties();
            // Try multiple locations
            InputStream fis = null;
            
            // Try 1: From resources folder
            fis = ObjectProvider.class.getClassLoader().getResourceAsStream("info.properties");
            
            // Try 2: From file system
            if(fis == null) {
                try {
                    fis = new FileInputStream("src/main/resources/info.properties");
                } catch(Exception e) {}
            }
            
            // Try 3: From WEB-INF/classes
            if(fis == null) {
                try {
                    fis = new FileInputStream("WEB-INF/classes/info.properties");
                } catch(Exception e) {}
            }
            
            if(fis != null) {
                p.load(fis);
                System.out.println("✅ info.properties loaded successfully");
                fis.close();
            } else {
                System.err.println("❌ info.properties not found!");
                // Set default values
                p.setProperty("BusinessClass", "serviceImpl.ShoppingServiceImpl");
                p.setProperty("DAOClass", "DAOImpl.DAOImplementation");
            }
        } catch(Exception e) {
            e.printStackTrace();
            p = new Properties();
            p.setProperty("BusinessClass", "serviceImpl.ShoppingServiceImpl");
            p.setProperty("DAOClass", "DAOImpl.DAOImplementation");
        }
    }

    public static ShoppingServiceInterface createServiceObject() {
        ShoppingServiceInterface service = null;
        try {
            String className = p.getProperty("BusinessClass");
            System.out.println("Loading BusinessClass: " + className);
            service = (ShoppingServiceInterface) Class.forName(className).newInstance();
            System.out.println("✅ Service object created: " + service);
        } catch(Exception e) {
            System.err.println("❌ Error creating service object:");
            e.printStackTrace();
        }
        return service;
    }
   
    public static DAOInterface createDAOObject() {
        DAOInterface dao = null;
        try {
            String className = p.getProperty("DAOClass");
            System.out.println("Loading DAOClass: " + className);
            dao = (DAOInterface) Class.forName(className).newInstance();
            System.out.println("✅ DAO object created: " + dao);
        } catch(Exception e) {
            System.err.println("❌ Error creating DAO object:");
            e.printStackTrace();
        }
        return dao;
    }
}