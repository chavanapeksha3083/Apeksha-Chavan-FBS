package DAOImpl;

import com.bean.User;
import com.bean.UserBudget;
import com.bean.Product;
import com.bean.StockNotification;
import com.bean.CartItem;
import com.bean.Order;
import com.bean.PriceAlert;

import aspect.provider.DBConnectionProvider;
import DAOInterface.DAOInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DAOImplementation implements DAOInterface 
{
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    // ========== USER Operations ==========
    @Override
    public boolean registerUser(User user)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO users(username, password, email, full_name, role) VALUES(?, ?, ?, ?, ?)";
            pst = con.prepareStatement(query);
            pst.setString(1, user.getUsername());
            pst.setString(2, user.getPassword());
            pst.setString(3, user.getEmail());
            pst.setString(4, user.getFullName());
            pst.setString(5, user.getRole());
            
            int count = pst.executeUpdate();
            System.out.println("Rows inserted: " + count);  // Debug
            return count > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();  // Console mein error dikhega
            return false;
        }
    }
    @Override
    public User validateUser(String username, String password)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                return user;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public User getUserById(int userId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM users WHERE user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(rs.getString("role"));
                return user;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public List<User> getAllUsers()
    {
        List<User> users = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM users WHERE role='customer'";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                users.add(user);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return users;
    }
    
    @Override
    public User getUserByUsername(String username)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM users WHERE username=?";
            pst = con.prepareStatement(query);
            pst.setString(1, username);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                return user;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public User getUserByEmail(String email)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM users WHERE email=?";
            pst = con.prepareStatement(query);
            pst.setString(1, email);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRole(rs.getString("role"));
                user.setCreatedAt(rs.getTimestamp("created_at"));
                return user;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    // ========== PRODUCT Operations ==========
    @Override
    public boolean addProduct(Product product)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO products(name, description, price, category, quantity, image_url) VALUES(?, ?, ?, ?, ?, ?)";
            pst = con.prepareStatement(query);
            pst.setString(1, product.getName());
            pst.setString(2, product.getDescription());
            pst.setDouble(3, product.getPrice());
            pst.setString(4, product.getCategory());
            pst.setInt(5, product.getQuantity());
            pst.setString(6, product.getImageUrl());
            
            int count = pst.executeUpdate();
            return count > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean updateProduct(Product product)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "UPDATE products SET name=?, description=?, price=?, category=?, quantity=?, image_url=? WHERE product_id=?";
            pst = con.prepareStatement(query);
            pst.setString(1, product.getName());
            pst.setString(2, product.getDescription());
            pst.setDouble(3, product.getPrice());
            pst.setString(4, product.getCategory());
            pst.setInt(5, product.getQuantity());
            pst.setString(6, product.getImageUrl());
            pst.setInt(7, product.getProductId());
            
            int count = pst.executeUpdate();
            return count > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean deleteProduct(int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM products WHERE product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, productId);
            
            int count = pst.executeUpdate();
            return count > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public Product getProductById(int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM products WHERE product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, productId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                return product;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public List<Product> getAllProducts()
    {
        List<Product> products = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM products";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                products.add(product);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return products;
    }
    
    @Override
    public List<Product> getProductsByCategory(String category)
    {
        List<Product> products = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM products WHERE category=?";
            pst = con.prepareStatement(query);
            pst.setString(1, category);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                products.add(product);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return products;
    }
    
    // ========== CART Operations ==========
    @Override
    public boolean addToCart(int userId, int productId, int quantity)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String checkQuery = "SELECT * FROM cart WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(checkQuery);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                int newQuantity = rs.getInt("quantity") + quantity;
                String updateQuery = "UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?";
                pst = con.prepareStatement(updateQuery);
                pst.setInt(1, newQuantity);
                pst.setInt(2, userId);
                pst.setInt(3, productId);
                return pst.executeUpdate() > 0;
            }
            else
            {
                String insertQuery = "INSERT INTO cart(user_id, product_id, quantity) VALUES(?, ?, ?)";
                pst = con.prepareStatement(insertQuery);
                pst.setInt(1, userId);
                pst.setInt(2, productId);
                pst.setInt(3, quantity);
                return pst.executeUpdate() > 0;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean updateCartItem(int cartId, int quantity)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "UPDATE cart SET quantity=? WHERE cart_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, quantity);
            pst.setInt(2, cartId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean removeFromCart(int cartId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM cart WHERE cart_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, cartId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<CartItem> getCartItems(int userId)
    {
        List<CartItem> cartItems = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT c.cart_id, c.user_id, c.quantity, p.product_id, p.name, p.description, p.price, p.category, p.image_url " +
                          "FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setImageUrl(rs.getString("image_url"));
                
                CartItem item = new CartItem(product, rs.getInt("quantity"));
                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                cartItems.add(item);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return cartItems;
    }
    
    @Override
    public void clearCart(int userId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM cart WHERE user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    @Override
    public int getProductIdByCartId(int cartId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT product_id FROM cart WHERE cart_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, cartId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                return rs.getInt("product_id");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return 0;
    }
    
    // ========== ORDER Operations ==========
    @Override
    public boolean createOrder(Order order)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO orders(user_id, total_amount, status, payment_method, card_number) VALUES(?, ?, ?, ?, ?)";
            pst = con.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.setInt(1, order.getUserId());
            pst.setDouble(2, order.getTotalAmount());
            pst.setString(3, order.getStatus());
            pst.setString(4, order.getPaymentMethod());
            pst.setString(5, order.getCardNumber());
            
            int count = pst.executeUpdate();
            if(count > 0)
            {
                rs = pst.getGeneratedKeys();
                if(rs.next())
                {
                    order.setOrderId(rs.getInt(1));
                }
                return true;
            }
            return false;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<Order> getOrdersByUser(int userId)
    {
        List<Order> orders = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM orders WHERE user_id=? ORDER BY order_date DESC";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setCardNumber(rs.getString("card_number"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                orders.add(order);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return orders;
    }
    
    @Override
    public List<Order> getAllOrders()
    {
        List<Order> orders = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT o.*, u.username, u.full_name FROM orders o JOIN users u ON o.user_id = u.user_id ORDER BY o.order_date DESC";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setCardNumber(rs.getString("card_number"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                orders.add(order);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return orders;
    }
    
    @Override
    public Order getOrderById(int orderId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM orders WHERE order_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, orderId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                Order order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setUserId(rs.getInt("user_id"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentMethod(rs.getString("payment_method"));
                order.setCardNumber(rs.getString("card_number"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                return order;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    // ========== WISHLIST Operations ==========
    @Override
    public boolean addToWishlist(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO wishlist(user_id, product_id) VALUES(?, ?)";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean removeFromWishlist(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM wishlist WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<Product> getWishlist(int userId)
    {
        List<Product> wishlist = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT p.* FROM products p JOIN wishlist w ON p.product_id = w.product_id WHERE w.user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                wishlist.add(product);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return wishlist;
    }
    
    @Override
    public boolean isInWishlist(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM wishlist WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            rs = pst.executeQuery();
            return rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    // ========== PRICE ALERT Operations ==========
    @Override
    public boolean addPriceAlert(int userId, int productId, double targetPrice)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO price_alerts(user_id, product_id, target_price) VALUES(?, ?, ?)";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            pst.setDouble(3, targetPrice);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean removePriceAlert(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM price_alerts WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<PriceAlert> getUserPriceAlerts(int userId)
    {
        List<PriceAlert> alerts = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT pa.*, p.name, p.price FROM price_alerts pa JOIN products p ON pa.product_id = p.product_id WHERE pa.user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                PriceAlert alert = new PriceAlert();
                alert.setAlertId(rs.getInt("alert_id"));
                alert.setUserId(rs.getInt("user_id"));
                alert.setProductId(rs.getInt("product_id"));
                alert.setTargetPrice(rs.getDouble("target_price"));
                alert.setCurrentPrice(rs.getDouble("price"));
                alert.setNotified(rs.getBoolean("is_notified"));
                alerts.add(alert);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return alerts;
    }
    
    @Override
    public List<PriceAlert> getPriceDropAlerts()
    {
        List<PriceAlert> alerts = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT pa.*, p.price FROM price_alerts pa JOIN products p ON pa.product_id = p.product_id WHERE p.price <= pa.target_price AND pa.is_notified=false";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                PriceAlert alert = new PriceAlert();
                alert.setAlertId(rs.getInt("alert_id"));
                alert.setUserId(rs.getInt("user_id"));
                alert.setProductId(rs.getInt("product_id"));
                alert.setTargetPrice(rs.getDouble("target_price"));
                alert.setCurrentPrice(rs.getDouble("price"));
                alerts.add(alert);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return alerts;
    }
    
    @Override
    public void markAlertNotified(int alertId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "UPDATE price_alerts SET is_notified=true WHERE alert_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, alertId);
            pst.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    // ========== STOCK NOTIFICATION Operations ==========
    @Override
    public boolean addStockNotification(int userId, int productId, String email)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO stock_notifications(user_id, product_id, email) VALUES(?, ?, ?)";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            pst.setString(3, email);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean removeStockNotification(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "DELETE FROM stock_notifications WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<StockNotification> getPendingStockNotifications(int productId)
    {
        List<StockNotification> notifications = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM stock_notifications WHERE product_id=? AND is_notified=false";
            pst = con.prepareStatement(query);
            pst.setInt(1, productId);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                StockNotification notif = new StockNotification();
                notif.setNotifyId(rs.getInt("notify_id"));
                notif.setUserId(rs.getInt("user_id"));
                notif.setProductId(rs.getInt("product_id"));
                notif.setEmail(rs.getString("email"));
                notifications.add(notif);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return notifications;
    }
    
    @Override
    public void markNotificationSent(int notifyId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "UPDATE stock_notifications SET is_notified=true WHERE notify_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, notifyId);
            pst.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    @Override
    public boolean isUserNotifiedForStock(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM stock_notifications WHERE user_id=? AND product_id=? AND is_notified=false";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            rs = pst.executeQuery();
            return rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    // ========== BROWSING HISTORY Operations ==========
    @Override
    public void addBrowsingHistory(int userId, int productId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            // Delete old entry for this product
            String deleteQuery = "DELETE FROM browsing_history WHERE user_id=? AND product_id=?";
            pst = con.prepareStatement(deleteQuery);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            pst.executeUpdate();
            
            // Add new entry
            String query = "INSERT INTO browsing_history(user_id, product_id) VALUES(?, ?)";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, productId);
            pst.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    @Override
    public List<Product> getRecommendedProducts(int userId, int limit)
    {
        List<Product> recommendations = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT DISTINCT p.* FROM products p " +
                          "WHERE p.category IN (SELECT DISTINCT p2.category FROM products p2 " +
                          "JOIN browsing_history bh ON p2.product_id = bh.product_id WHERE bh.user_id=?) " +
                          "AND p.product_id NOT IN (SELECT product_id FROM browsing_history WHERE user_id=?) " +
                          "AND p.quantity > 0 LIMIT ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, userId);
            pst.setInt(3, limit);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                recommendations.add(product);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return recommendations;
    }
    
    @Override
    public List<Product> getRecentlyViewed(int userId, int limit)
    {
        List<Product> recent = new ArrayList<>();
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT p.* FROM products p JOIN browsing_history bh ON p.product_id = bh.product_id " +
                          "WHERE bh.user_id=? ORDER BY bh.viewed_at DESC LIMIT ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setInt(2, limit);
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setCategory(rs.getString("category"));
                product.setQuantity(rs.getInt("quantity"));
                product.setImageUrl(rs.getString("image_url"));
                recent.add(product);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return recent;
    }
    
    // ========== BUDGET Operations ==========
    @Override
    public boolean setUserBudget(int userId, double monthlyBudget, int alertPercentage)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "INSERT INTO user_budgets(user_id, monthly_budget, alert_percentage) VALUES(?, ?, ?) " +
                          "ON DUPLICATE KEY UPDATE monthly_budget=?, alert_percentage=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            pst.setDouble(2, monthlyBudget);
            pst.setInt(3, alertPercentage);
            pst.setDouble(4, monthlyBudget);
            pst.setInt(5, alertPercentage);
            return pst.executeUpdate() > 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public UserBudget getUserBudget(int userId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT * FROM user_budgets WHERE user_id=?";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                UserBudget budget = new UserBudget();
                budget.setBudgetId(rs.getInt("budget_id"));
                budget.setUserId(rs.getInt("user_id"));
                budget.setMonthlyBudget(rs.getDouble("monthly_budget"));
                budget.setAlertPercentage(rs.getInt("alert_percentage"));
                return budget;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public double getTotalSpentThisMonth(int userId)
    {
        try
        {
            con = DBConnectionProvider.createConnection();
            String query = "SELECT COALESCE(SUM(total_amount), 0) as total FROM orders " +
                          "WHERE user_id=? AND MONTH(order_date)=MONTH(CURRENT_DATE()) " +
                          "AND YEAR(order_date)=YEAR(CURRENT_DATE())";
            pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                return rs.getDouble("total");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return 0;
    }
}
    
    
// ❌ REMOVE THIS DUPLICATE LINE - Yeh error create kar raha hai!
// public class DAOImplementation implements DAOInterface    DAOImplementation