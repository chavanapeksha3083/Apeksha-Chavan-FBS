package serviceImpl;

import java.util.List;
import com.bean.User;
import com.bean.Product;
import com.bean.CartItem;
import com.bean.Order;
import com.bean.PriceAlert;
import com.bean.StockNotification;
import com.bean.UserBudget;
import DAOInterface.DAOInterface;
import aspect.provider.ObjectProvider;
import serviceInterface.ShoppingServiceInterface;

public class ShoppingServiceImpl implements ShoppingServiceInterface
{
    DAOInterface dao = ObjectProvider.createDAOObject();
    
    // ========== USER SERVICES ==========
    @Override
    public boolean registerUser(User user)
    {
        user.setRole("customer");
        return dao.registerUser(user);
    }
    
    @Override
    public User loginUser(String username, String password)
    {
        return dao.validateUser(username, password);
    }
    
    @Override
    public boolean isAdmin(User user)
    {
        return user != null && "admin".equals(user.getRole());
    }
    
    @Override
    public List<User> getAllUsers()
    {
        return dao.getAllUsers();
    }
    
    @Override
    public User getUserByUsername(String username)
    {
        return dao.getUserByUsername(username);
    }
    
    @Override
    public User getUserByEmail(String email)
    {
        return dao.getUserByEmail(email);
    }
    
    // ========== PRODUCT SERVICES ==========
    @Override
    public boolean addProduct(Product product)
    {
        return dao.addProduct(product);
    }
    
    @Override
    public boolean updateProduct(Product product)
    {
        return dao.updateProduct(product);
    }
    
    @Override
    public boolean deleteProduct(int productId)
    {
        return dao.deleteProduct(productId);
    }
    
    @Override
    public Product getProductById(int productId)
    {
        return dao.getProductById(productId);
    }
    
    @Override
    public List<Product> getAllProducts()
    {
        return dao.getAllProducts();
    }
    
    @Override
    public List<Product> getProductsByCategory(String category)
    {
        return dao.getProductsByCategory(category);
    }
    
    // ========== CART SERVICES ==========
    @Override
    public boolean addToCart(int userId, int productId, int quantity)
    {
        Product product = dao.getProductById(productId);
        if(product != null && product.getQuantity() >= quantity)
        {
            return dao.addToCart(userId, productId, quantity);
        }
        return false;
    }
    
    @Override
    public boolean updateCartItem(int cartId, int quantity)
    {
        return dao.updateCartItem(cartId, quantity);
    }
    
    @Override
    public boolean removeFromCart(int cartId)
    {
        return dao.removeFromCart(cartId);
    }
    
    @Override
    public List<CartItem> getCartItems(int userId)
    {
        return dao.getCartItems(userId);
    }
    
    @Override
    public double getCartTotal(int userId)
    {
        List<CartItem> items = dao.getCartItems(userId);
        double total = 0;
        for(CartItem item : items)
        {
            total += item.getSubtotal();
        }
        return total;
    }
    
    @Override
    public void clearCart(int userId)
    {
        dao.clearCart(userId);
    }
    
    @Override
    public int getProductIdByCartId(int cartId)
    {
        return dao.getProductIdByCartId(cartId);
    }
    
    // ========== ORDER SERVICES ==========
    @Override
    public boolean processOrder(int userId, String paymentMethod, String cardNumber)
    {
        double total = getCartTotal(userId);
        if(total > 0)
        {
            Order order = new Order(userId, total, paymentMethod, cardNumber);
            boolean orderCreated = dao.createOrder(order);
            if(orderCreated)
            {
                dao.clearCart(userId);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public List<Order> getUserOrders(int userId)
    {
        return dao.getOrdersByUser(userId);
    }
    
    @Override
    public List<Order> getAllOrders()
    {
        return dao.getAllOrders();
    }
    
    // ========== WISHLIST SERVICES ==========
    @Override
    public boolean addToWishlist(int userId, int productId)
    {
        return dao.addToWishlist(userId, productId);
    }
    
    @Override
    public boolean removeFromWishlist(int userId, int productId)
    {
        return dao.removeFromWishlist(userId, productId);
    }
    
    @Override
    public List<Product> getWishlist(int userId)
    {
        return dao.getWishlist(userId);
    }
    
    @Override
    public boolean isInWishlist(int userId, int productId)
    {
        return dao.isInWishlist(userId, productId);
    }
    
    // ========== PRICE ALERT SERVICES ==========
    @Override
    public boolean addPriceAlert(int userId, int productId, double targetPrice)
    {
        return dao.addPriceAlert(userId, productId, targetPrice);
    }
    
    @Override
    public boolean removePriceAlert(int userId, int productId)
    {
        return dao.removePriceAlert(userId, productId);
    }
    
    @Override
    public List<PriceAlert> getUserPriceAlerts(int userId)
    {
        return dao.getUserPriceAlerts(userId);
    }
    
    @Override
    public List<PriceAlert> getPriceDropAlerts()
    {
        return dao.getPriceDropAlerts();
    }
    
    @Override
    public void checkAndSendPriceAlerts()
    {
        List<PriceAlert> alerts = dao.getPriceDropAlerts();
        for(PriceAlert alert : alerts)
        {
            System.out.println("🔔 Price Drop Alert! Product ID: " + alert.getProductId() + 
                              " is now $" + alert.getCurrentPrice());
            dao.markAlertNotified(alert.getAlertId());
        }
    }
    
    // ========== STOCK NOTIFICATION SERVICES ==========
    @Override
    public boolean addStockNotification(int userId, int productId, String email)
    {
        return dao.addStockNotification(userId, productId, email);
    }
    
    @Override
    public boolean removeStockNotification(int userId, int productId)
    {
        return dao.removeStockNotification(userId, productId);
    }
    
    @Override
    public boolean isUserNotifiedForStock(int userId, int productId)
    {
        return dao.isUserNotifiedForStock(userId, productId);
    }
    
    @Override
    public void sendStockBackInStockAlerts(int productId)
    {
        List<StockNotification> notifications = dao.getPendingStockNotifications(productId);
        for(StockNotification notification : notifications)
        {
            System.out.println("📧 Back in Stock Alert for: " + notification.getEmail());
            dao.markNotificationSent(notification.getNotifyId());
        }
    }
    
    // ========== BROWSING HISTORY SERVICES ==========
    @Override
    public void addBrowsingHistory(int userId, int productId)
    {
        dao.addBrowsingHistory(userId, productId);
    }
    
    @Override
    public List<Product> getRecommendedProducts(int userId, int limit)
    {
        return dao.getRecommendedProducts(userId, limit);
    }
    
    @Override
    public List<Product> getRecentlyViewed(int userId, int limit)
    {
        return dao.getRecentlyViewed(userId, limit);
    }
    
    // ========== BUDGET SERVICES ==========
    @Override
    public boolean setUserBudget(int userId, double monthlyBudget, int alertPercentage)
    {
        return dao.setUserBudget(userId, monthlyBudget, alertPercentage);
    }
    
    @Override
    public UserBudget getUserBudget(int userId)
    {
        return dao.getUserBudget(userId);
    }
    
    @Override
    public double getTotalSpentThisMonth(int userId)
    {
        return dao.getTotalSpentThisMonth(userId);
    }
    
    @Override
    public double getRemainingBudget(int userId)
    {
        UserBudget budget = dao.getUserBudget(userId);
        double spent = dao.getTotalSpentThisMonth(userId);
        if(budget != null)
        {
            return budget.getMonthlyBudget() - spent;
        }
        return 0;
    }
    
    @Override
    public boolean isBudgetExceeded(int userId, double additionalAmount)
    {
        UserBudget budget = dao.getUserBudget(userId);
        if(budget != null)
        {
            double spent = dao.getTotalSpentThisMonth(userId);
            return (spent + additionalAmount) > budget.getMonthlyBudget();
        }
        return false;
    }
    
    // ========== STOCK VALIDATION SERVICES ==========
    @Override
    public boolean isProductInStock(int productId)
    {
        Product product = dao.getProductById(productId);
        return product != null && product.getQuantity() > 0;
    }
    
    @Override
    public boolean isQuantityAvailable(int productId, int requestedQuantity)
    {
        Product product = dao.getProductById(productId);
        return product != null && product.getQuantity() >= requestedQuantity;
    }
    
    @Override
    public int getAvailableStock(int productId)
    {
        Product product = dao.getProductById(productId);
        return product != null ? product.getQuantity() : 0;
    }
}