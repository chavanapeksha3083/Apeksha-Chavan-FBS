package serviceInterface;

import java.util.List;
import com.bean.User;
import com.bean.Product;
import com.bean.CartItem;
import com.bean.Order;
import com.bean.PriceAlert;
import com.bean.StockNotification;
import com.bean.UserBudget;

public interface ShoppingServiceInterface
{
    // ========== USER SERVICES ==========
    boolean registerUser(User user);
    User loginUser(String username, String password);
    boolean isAdmin(User user);
    List<User> getAllUsers();
    User getUserByUsername(String username);
    User getUserByEmail(String email);
    
    // ========== PRODUCT SERVICES ==========
    boolean addProduct(Product product);
    boolean updateProduct(Product product);
    boolean deleteProduct(int productId);
    Product getProductById(int productId);
    List<Product> getAllProducts();
    List<Product> getProductsByCategory(String category);
    
    // ========== CART SERVICES ==========
    boolean addToCart(int userId, int productId, int quantity);
    boolean updateCartItem(int cartId, int quantity);
    boolean removeFromCart(int cartId);
    List<CartItem> getCartItems(int userId);
    double getCartTotal(int userId);
    void clearCart(int userId);
    int getProductIdByCartId(int cartId);
    
    // ========== ORDER SERVICES ==========
    boolean processOrder(int userId, String paymentMethod, String cardNumber);
    List<Order> getUserOrders(int userId);
    List<Order> getAllOrders();
    
    // ========== WISHLIST SERVICES ==========
    boolean addToWishlist(int userId, int productId);
    boolean removeFromWishlist(int userId, int productId);
    List<Product> getWishlist(int userId);
    boolean isInWishlist(int userId, int productId);
    
    // ========== PRICE ALERT SERVICES ==========
    boolean addPriceAlert(int userId, int productId, double targetPrice);
    boolean removePriceAlert(int userId, int productId);
    List<PriceAlert> getUserPriceAlerts(int userId);
    List<PriceAlert> getPriceDropAlerts();
    void checkAndSendPriceAlerts();
    
    // ========== STOCK NOTIFICATION SERVICES ==========
    boolean addStockNotification(int userId, int productId, String email);
    boolean removeStockNotification(int userId, int productId);
    boolean isUserNotifiedForStock(int userId, int productId);
    void sendStockBackInStockAlerts(int productId);
    
    // ========== BROWSING HISTORY SERVICES ==========
    void addBrowsingHistory(int userId, int productId);
    List<Product> getRecommendedProducts(int userId, int limit);
    List<Product> getRecentlyViewed(int userId, int limit);
    
    // ========== BUDGET SERVICES ==========
    boolean setUserBudget(int userId, double monthlyBudget, int alertPercentage);
    UserBudget getUserBudget(int userId);
    double getTotalSpentThisMonth(int userId);
    double getRemainingBudget(int userId);
    boolean isBudgetExceeded(int userId, double additionalAmount);
    
    // ========== STOCK VALIDATION SERVICES ==========
    boolean isProductInStock(int productId);
    boolean isQuantityAvailable(int productId, int requestedQuantity);
    int getAvailableStock(int productId);
}