package com.myservlet;

import java.io.PrintWriter;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            String category = request.getParameter("category");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String rawImageUrl = request.getParameter("imageUrl");
            
            // 🔥 FIX: Convert Google image search URL to direct image URL
            String finalImageUrl = convertGoogleUrlToDirect(rawImageUrl);
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "INSERT INTO products (name, description, price, category, quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setString(4, category);
            pst.setInt(5, quantity);
            pst.setString(6, finalImageUrl);
            pst.executeUpdate();
            pst.close();
            con.close();
            
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('✅ Product added successfully!'); window.location='admin-dashboard.jsp?msg=product_added';</script>");
            
        } catch(Exception e) {
            e.printStackTrace();
            try {
                response.getWriter().println("<script>alert('Error: " + e.getMessage() + "'); window.location='add-product.jsp';</script>");
            } catch(Exception ex) {}
        }
    }
    
    // 🔧 Helper method to extract direct image URL from Google search URL
    private String convertGoogleUrlToDirect(String url) {
        if (url == null || url.isEmpty()) return "https://placehold.co/300x200/ff9900/white?text=No+Image";
        
        // If it's already a direct image (jpg, png, webp, etc.), return as is
        if (url.matches(".*\\.(jpg|jpeg|png|gif|webp)(\\?.*)?$")) {
            return url;
        }
        
        // If it's a Google imgres URL
        if (url.contains("google.com/imgres")) {
            try {
                // Extract the 'imgurl' parameter
                String imgurlParam = "imgurl=";
                int start = url.indexOf(imgurlParam);
                if (start != -1) {
                    start += imgurlParam.length();
                    int end = url.indexOf("&", start);
                    if (end == -1) end = url.length();
                    String encodedUrl = url.substring(start, end);
                    String decodedUrl = URLDecoder.decode(encodedUrl, "UTF-8");
                    return decodedUrl;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        // If no conversion possible, return a fallback placeholder
        return "https://placehold.co/300x200/ff9900/white?text=Invalid+URL";
    }
}