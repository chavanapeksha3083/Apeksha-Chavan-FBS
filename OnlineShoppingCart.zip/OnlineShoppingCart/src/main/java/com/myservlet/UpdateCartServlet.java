package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/UpdateCartServlet")
public class UpdateCartServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int cartId = Integer.parseInt(request.getParameter("cartId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            if(quantity <= 0) {
                // Remove item if quantity is 0 or negative
                String deleteQuery = "DELETE FROM cart WHERE cart_id = ?";
                Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement pst = con.prepareStatement(deleteQuery);
                pst.setInt(1, cartId);
                pst.executeUpdate();
                pst.close();
                con.close();
            } else {
                // Update quantity
                String updateQuery = "UPDATE cart SET quantity = ? WHERE cart_id = ?";
                Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement pst = con.prepareStatement(updateQuery);
                pst.setInt(1, quantity);
                pst.setInt(2, cartId);
                pst.executeUpdate();
                pst.close();
                con.close();
            }
            
            response.sendRedirect("ViewCartServlet");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}