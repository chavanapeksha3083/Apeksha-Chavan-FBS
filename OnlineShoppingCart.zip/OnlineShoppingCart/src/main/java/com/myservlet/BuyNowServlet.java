package com.myservlet;

import java.io.PrintWriter;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/BuyNowServlet")
public class BuyNowServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        PrintWriter out = null;
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            int userId = (Integer) session.getAttribute("userId");
            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            con.setAutoCommit(false);

            // Get product details
            PreparedStatement pst = con.prepareStatement("SELECT name, price, image_url FROM products WHERE product_id = ?");
            pst.setInt(1, productId);
            ResultSet rs = pst.executeQuery();
            if (!rs.next()) {
                response.getWriter().println("<h3>Product not found</h3>");
                return;
            }
            String productName = rs.getString("name");
            double price = rs.getDouble("price");
            String imageUrl = rs.getString("image_url");
            rs.close();
            pst.close();

            double total = price * quantity;

            // Insert into orders table
            PreparedStatement orderStmt = con.prepareStatement(
                "INSERT INTO orders (user_id, total_amount, status, payment_method) VALUES (?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS);
            orderStmt.setInt(1, userId);
            orderStmt.setDouble(2, total);
            orderStmt.setString(3, "confirmed");
            orderStmt.setString(4, "Online Payment");
            orderStmt.executeUpdate();
            ResultSet generatedKeys = orderStmt.getGeneratedKeys();
            int orderId = 0;
            if (generatedKeys.next()) orderId = generatedKeys.getInt(1);
            orderStmt.close();

            // ✅ Insert into order_items (with fallback – agar fail ho to bhi order save rahega)
            try {
                PreparedStatement itemStmt = con.prepareStatement(
                    "INSERT INTO order_items (order_id, product_id, product_name, product_price, product_image, quantity) VALUES (?, ?, ?, ?, ?, ?)");
                itemStmt.setInt(1, orderId);
                itemStmt.setInt(2, productId);
                itemStmt.setString(3, productName);
                itemStmt.setDouble(4, price);
                itemStmt.setString(5, imageUrl);
                itemStmt.setInt(6, quantity);
                itemStmt.executeUpdate();
                itemStmt.close();
            } catch (SQLException e) {
                // Agar order_items table missing hai ya koi error hai, toh sirf log karo – order already saved hai
                System.err.println("Order items insert failed (non-critical): " + e.getMessage());
                // Rollback nahi karna – order already saved hai
            }

            // Update stock
            PreparedStatement updateStock = con.prepareStatement("UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
            updateStock.setInt(1, quantity);
            updateStock.setInt(2, productId);
            updateStock.executeUpdate();
            updateStock.close();

            con.commit();
            con.close();

            // Show success page
            response.setContentType("text/html");
            out = response.getWriter();
            out.println("<!DOCTYPE html><html><head><title>Order Placed</title>");
            out.println("<style>body{font-family:Arial;background:#1a1a2e;display:flex;justify-content:center;align-items:center;height:100vh;}");
            out.println(".card{background:linear-gradient(135deg,#10b981,#059669);padding:40px;border-radius:20px;text-align:center;color:white;max-width:400px;}");
            out.println(".icon{width:70px;height:70px;background:white;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;}");
            out.println(".icon i{font-size:40px;color:#059669;}</style>");
            out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>");
            out.println("</head><body><div class='card'><div class='icon'><i class='fas fa-check-circle'></i></div>");
            out.println("<h2>Order Placed Successfully!</h2>");
            out.println("<p>" + productName + "<br>Quantity: " + quantity + "<br>Total: ₹" + String.format("%,.0f", total) + "</p>");
            out.println("<a href='MyOrdersServlet' style='color:white;margin:10px;display:inline-block;'>View Orders</a>");
            out.println("<a href='products.jsp' style='color:white;margin:10px;display:inline-block;'>Continue Shopping</a>");
            out.println("</div></body></html>");
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (out != null) {
                    out.println("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
                    out.println("<a href='products.jsp'>Go back</a>");
                } else {
                    response.getWriter().println("<h3>Error: " + e.getMessage() + "</h3><a href='products.jsp'>Go back</a>");
                }
            } catch (Exception ex) {}
        }
    }
}