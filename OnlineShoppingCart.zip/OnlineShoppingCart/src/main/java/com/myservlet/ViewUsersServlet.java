package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ViewUsersServlet")
public class ViewUsersServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            String query = "SELECT user_id, username, email, full_name, created_at FROM users WHERE role = 'customer' ORDER BY user_id DESC";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            
            List<Map<String, Object>> users = new ArrayList<>();
            while(rs.next()) {
                Map<String, Object> user = new HashMap<>();
                user.put("userId", rs.getInt("user_id"));
                user.put("username", rs.getString("username"));
                user.put("email", rs.getString("email"));
                user.put("fullName", rs.getString("full_name"));
                user.put("createdAt", rs.getTimestamp("created_at"));
                users.add(user);
            }
            
            session.setAttribute("users", users);
            
            rs.close();
            pst.close();
            con.close();
            
            response.sendRedirect("view-users.jsp");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}