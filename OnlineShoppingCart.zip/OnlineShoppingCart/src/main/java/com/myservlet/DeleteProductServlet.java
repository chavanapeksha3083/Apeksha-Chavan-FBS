package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            int productId = Integer.parseInt(request.getParameter("productId"));
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            PreparedStatement pst = con.prepareStatement("DELETE FROM products WHERE product_id = ?");
            pst.setInt(1, productId);
            int deleted = pst.executeUpdate();
            pst.close();
            con.close();
            
            if (deleted > 0) {
                // ✅ Success – redirect with message
                response.sendRedirect("admin-dashboard.jsp?msg=product_deleted");
            } else {
                // ❌ Product not found or error
                response.sendRedirect("admin-dashboard.jsp?msg=delete_failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.sendRedirect("admin-dashboard.jsp?msg=delete_error");
            } catch (Exception ex) {}
        }
    }
}