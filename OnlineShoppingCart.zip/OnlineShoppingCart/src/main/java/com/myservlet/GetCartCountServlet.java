package com.myservlet;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/GetCartCountServlet")
public class GetCartCountServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root"; // CHANGE TO YOUR PASSWORD
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            
            if(session == null || session.getAttribute("user") == null) {
                out.print("0");
                return;
            }
            
            int userId = (Integer) session.getAttribute("userId");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            PreparedStatement pst = con.prepareStatement("SELECT SUM(quantity) as total FROM cart WHERE user_id=?");
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            
            int count = 0;
            if(rs.next()) {
                count = rs.getInt("total");
            }
            
            out.print(count);
            
            rs.close();
            pst.close();
            con.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}