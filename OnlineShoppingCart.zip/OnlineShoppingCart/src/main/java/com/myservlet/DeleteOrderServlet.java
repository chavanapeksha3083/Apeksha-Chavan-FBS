package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DeleteOrderServlet")
public class DeleteOrderServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // First delete from order_items if table exists (to avoid foreign key error)
            try {
                PreparedStatement pstItems = con.prepareStatement("DELETE FROM order_items WHERE order_id = ?");
                pstItems.setInt(1, orderId);
                pstItems.executeUpdate();
                pstItems.close();
            } catch(Exception e) {
                // order_items table might not exist – ignore
            }
            
            // Delete the order
            PreparedStatement pst = con.prepareStatement("DELETE FROM orders WHERE order_id = ?");
            pst.setInt(1, orderId);
            int deleted = pst.executeUpdate();
            pst.close();
            con.close();
            
            if(deleted > 0) {
                response.sendRedirect("ViewOrdersServlet?msg=deleted");
            } else {
                response.sendRedirect("ViewOrdersServlet?msg=error");
            }
        } catch(Exception e) {
            e.printStackTrace();
            try {
                response.sendRedirect("ViewOrdersServlet?msg=error");
            } catch(Exception ex) {}
        }
    }
}