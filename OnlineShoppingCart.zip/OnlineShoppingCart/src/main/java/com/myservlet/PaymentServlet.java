package com.myservlet;

import java.io.PrintWriter;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import serviceInterface.ShoppingServiceInterface;
import aspect.provider.ObjectProvider;

public class PaymentServlet extends HttpServlet
{
    ShoppingServiceInterface service = ObjectProvider.createServiceObject();
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null)
            {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int userId = (int) session.getAttribute("userId");
            String cardNumber = request.getParameter("cardNumber");
            String expiryDate = request.getParameter("expiryDate");
            String cvv = request.getParameter("cvv");
            String cardHolderName = request.getParameter("cardHolderName");
            
            // Basic validation
            if(cardNumber == null || cardNumber.trim().isEmpty() ||
               expiryDate == null || expiryDate.trim().isEmpty() ||
               cvv == null || cvv.trim().isEmpty() ||
               cardHolderName == null || cardHolderName.trim().isEmpty())
            {
                RequestDispatcher rd = request.getRequestDispatcher("payment.jsp");
                rd.include(request, response);
                out.println("<div class='error-msg'>Please fill all payment details!</div>");
                return;
            }
            
            // Process order
            boolean orderProcessed = service.processOrder(userId, "Credit Card", cardNumber);
            
            if(orderProcessed)
            {
                session.setAttribute("orderSuccess", true);
                response.sendRedirect("order-confirmation.jsp");
            }
            else
            {
                RequestDispatcher rd = request.getRequestDispatcher("payment.jsp");
                rd.include(request, response);
                out.println("<div class='error-msg'>Payment failed! Please try again.</div>");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}