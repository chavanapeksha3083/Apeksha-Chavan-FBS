package com.myservlet;

import java.sql.*;
import java.util.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/MyOrdersServlet")
public class MyOrdersServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }

            int userId = (Integer) session.getAttribute("userId");
            System.out.println("MyOrdersServlet: Fetching orders for user ID = " + userId);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "SELECT order_id, total_amount, status, payment_method, order_date FROM orders WHERE user_id = ? ORDER BY order_date DESC";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();

            List<Map<String, Object>> orders = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("orderId", rs.getInt("order_id"));
                order.put("total", rs.getDouble("total_amount"));
                order.put("status", rs.getString("status"));
                order.put("paymentMethod", rs.getString("payment_method"));
                order.put("date", rs.getTimestamp("order_date"));
                orders.add(order);
                System.out.println("Found order ID: " + order.get("orderId"));
            }
            session.setAttribute("myOrders", orders);
            rs.close();
            pst.close();
            con.close();

            response.sendRedirect("customer-orders.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            try {
                response.getWriter().println("Error: " + e.getMessage());
            } catch (Exception ex) {}
        }
    }
}