package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/WishlistServlet")
public class WishlistServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            int userId = (Integer) session.getAttribute("userId");
            int productId = Integer.parseInt(request.getParameter("productId"));

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Check if already in wishlist
            PreparedStatement check = con.prepareStatement("SELECT * FROM wishlist WHERE user_id = ? AND product_id = ?");
            check.setInt(1, userId);
            check.setInt(2, productId);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                // Remove
                PreparedStatement delete = con.prepareStatement("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
                delete.setInt(1, userId);
                delete.setInt(2, productId);
                delete.executeUpdate();
                delete.close();
            } else {
                // Add
                PreparedStatement insert = con.prepareStatement("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
                insert.setInt(1, userId);
                insert.setInt(2, productId);
                insert.executeUpdate();
                insert.close();
            }
            rs.close();
            check.close();
            con.close();

            // Redirect back to the same page
            String referer = request.getHeader("referer");
            if (referer != null && !referer.isEmpty()) {
                response.sendRedirect(referer);
            } else {
                response.sendRedirect("products.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}