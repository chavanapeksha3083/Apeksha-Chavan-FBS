package com.myservlet;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30"; // Change to your MySQL password
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    {
        PrintWriter out = null;
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        try
        {
            response.setContentType("text/html");
            out = response.getWriter();
            
            // Get parameters from form
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String email = request.getParameter("email");
            String fullName = request.getParameter("fullName");
            
            System.out.println("=== Registration Attempt ===");
            System.out.println("Username: " + username);
            System.out.println("Email: " + email);
            System.out.println("Full Name: " + fullName);
            
            // Validation
            if(username == null || username.trim().isEmpty())
            {
                showError(request, response, out, "Username is required!");
                return;
            }
            
            if(password == null || password.trim().isEmpty())
            {
                showError(request, response, out, "Password is required!");
                return;
            }
            
            if(password.length() < 6)
            {
                showError(request, response, out, "Password must be at least 6 characters!");
                return;
            }
            
            if(email == null || email.trim().isEmpty())
            {
                showError(request, response, out, "Email is required!");
                return;
            }
            
            if(fullName == null || fullName.trim().isEmpty())
            {
                showError(request, response, out, "Full Name is required!");
                return;
            }
            
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Create connection
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("✅ Database connected!");
            
            // Check if username already exists
            String checkUserQuery = "SELECT * FROM users WHERE username = ?";
            pst = con.prepareStatement(checkUserQuery);
            pst.setString(1, username);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                showError(request, response, out, "Username already exists! Please choose another.");
                return;
            }
            rs.close();
            pst.close();
            
            // Check if email already exists
            String checkEmailQuery = "SELECT * FROM users WHERE email = ?";
            pst = con.prepareStatement(checkEmailQuery);
            pst.setString(1, email);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                showError(request, response, out, "Email already registered! Please use another email.");
                return;
            }
            rs.close();
            pst.close();
            
            // Insert new user
            String insertQuery = "INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, 'customer')";
            pst = con.prepareStatement(insertQuery);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, email);
            pst.setString(4, fullName);
            
            int result = pst.executeUpdate();
            
            if(result > 0)
            {
                System.out.println("✅ Registration SUCCESSFUL for: " + username);
                response.sendRedirect("login.jsp?msg=registered&username=" + username);
            }
            else
            {
                showError(request, response, out, "Registration failed! Please try again.");
            }
        }
        catch(Exception e)
        {
            System.out.println("❌ Exception in RegisterServlet:");
            e.printStackTrace();
            try {
                showError(request, response, out, "Database Error: " + e.getMessage());
            } catch(Exception ex) {}
        }
        finally
        {
            try { if(rs != null) rs.close(); } catch(Exception e) {}
            try { if(pst != null) pst.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
    }
    
    private void showError(HttpServletRequest request, HttpServletResponse response, PrintWriter out, String errorMsg) throws Exception
    {
        RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
        rd.include(request, response);
        out.println("<div class='error-msg' style='background:rgba(239,68,68,0.2); color:#f87171; padding:12px; border-radius:10px; margin-bottom:20px; text-align:center;'>❌ " + errorMsg + "</div>");
    }
}