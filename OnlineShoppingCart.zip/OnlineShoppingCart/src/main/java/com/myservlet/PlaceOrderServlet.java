package com.myservlet;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@WebServlet("/PlaceOrderServlet")
public class PlaceOrderServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int userId = (Integer) session.getAttribute("userId");
            List<Map<String, Object>> cartItems = (List<Map<String, Object>>) session.getAttribute("cartItems");
            Double total = (Double) session.getAttribute("cartTotal");
            
            if(cartItems == null || cartItems.isEmpty()) {
                response.sendRedirect("cart.jsp");
                return;
            }
            
            // Check stock before placing order
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            boolean stockAvailable = true;
            String outOfStockMessage = "";
            
            for(Map<String, Object> item : cartItems) {
                int productId = (Integer) item.get("productId");
                int requestedQty = (Integer) item.get("quantity");
                
                String checkQuery = "SELECT quantity, name FROM products WHERE product_id = ?";
                PreparedStatement pst = con.prepareStatement(checkQuery);
                pst.setInt(1, productId);
                java.sql.ResultSet rs = pst.executeQuery();
                
                if(rs.next()) {
                    int availableStock = rs.getInt("quantity");
                    String productName = rs.getString("name");
                    
                    if(availableStock < requestedQty) {
                        stockAvailable = false;
                        outOfStockMessage = productName + " is only " + availableStock + " left in stock!";
                        break;
                    }
                }
                rs.close();
                pst.close();
            }
            
            if(!stockAvailable) {
                // Show error message on cart page
                session.setAttribute("stockError", outOfStockMessage);
                response.sendRedirect("cart.jsp");
                return;
            }
            
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String address = request.getParameter("address");
            String city = request.getParameter("city");
            String pincode = request.getParameter("pincode");
            String phone = request.getParameter("phone");
            String paymentMethod = request.getParameter("paymentMethod");
            
            String addressFull = firstName + " " + lastName + ", " + address + ", " + city + " - " + pincode + ", Phone: " + phone;
            
            // Insert order
            String orderQuery = "INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(orderQuery);
            pst.setInt(1, userId);
            pst.setDouble(2, total);
            
            if(paymentMethod.equals("COD")) {
                pst.setString(3, "pending");
            } else {
                pst.setString(3, "confirmed");
            }
            
            pst.setString(4, paymentMethod);
            pst.setString(5, addressFull);
            pst.executeUpdate();
            
            // Update stock - deduct quantities
            for(Map<String, Object> item : cartItems) {
                int productId = (Integer) item.get("productId");
                int requestedQty = (Integer) item.get("quantity");
                
                String updateStock = "UPDATE products SET quantity = quantity - ? WHERE product_id = ?";
                PreparedStatement updateStmt = con.prepareStatement(updateStock);
                updateStmt.setInt(1, requestedQty);
                updateStmt.setInt(2, productId);
                updateStmt.executeUpdate();
                updateStmt.close();
            }
            
            // Clear cart
            String clearCart = "DELETE FROM cart WHERE user_id = ?";
            pst = con.prepareStatement(clearCart);
            pst.setInt(1, userId);
            pst.executeUpdate();
            
            pst.close();
            con.close();
            
            session.removeAttribute("cartItems");
            session.removeAttribute("cartTotal");
            session.setAttribute("orderSuccess", true);
            session.setAttribute("paymentMethod", paymentMethod);
            
            // Show success page with green background
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Order Placed Successfully</title>");
            out.println("<style>");
            out.println("* { margin: 0; padding: 0; box-sizing: border-box; }");
            out.println("body {");
            out.println("    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;");
            out.println("    background: linear-gradient(135deg, #0a0e27 0%, #0f172a 30%, #1e1b4b 70%, #0a0e27 100%);");
            out.println("    min-height: 100vh;");
            out.println("    display: flex;");
            out.println("    justify-content: center;");
            out.println("    align-items: center;");
            out.println("}");
            out.println(".success-card {");
            out.println("    background: linear-gradient(135deg, #10b981, #059669);");
            out.println("    border-radius: 20px;");
            out.println("    padding: 50px;");
            out.println("    text-align: center;");
            out.println("    max-width: 500px;");
            out.println("    margin: 20px;");
            out.println("    box-shadow: 0 20px 40px rgba(0,0,0,0.2);");
            out.println("    animation: fadeIn 0.5s ease;");
            out.println("}");
            out.println("@keyframes fadeIn {");
            out.println("    from { opacity: 0; transform: scale(0.9); }");
            out.println("    to { opacity: 1; transform: scale(1); }");
            out.println("}");
            out.println(".success-icon {");
            out.println("    width: 80px;");
            out.println("    height: 80px;");
            out.println("    background: white;");
            out.println("    border-radius: 50%;");
            out.println("    display: flex;");
            out.println("    align-items: center;");
            out.println("    justify-content: center;");
            out.println("    margin: 0 auto 20px;");
            out.println("}");
            out.println(".success-icon i {");
            out.println("    font-size: 40px;");
            out.println("    color: #059669;");
            out.println("}");
            out.println(".success-card h2 {");
            out.println("    color: white;");
            out.println("    margin-bottom: 15px;");
            out.println("    font-size: 28px;");
            out.println("}");
            out.println(".success-card p {");
            out.println("    color: rgba(255,255,255,0.9);");
            out.println("    margin-bottom: 10px;");
            out.println("}");
            out.println(".btn-group {");
            out.println("    margin-top: 30px;");
            out.println("    display: flex;");
            out.println("    gap: 15px;");
            out.println("    justify-content: center;");
            out.println("}");
            out.println(".btn {");
            out.println("    padding: 12px 25px;");
            out.println("    border: none;");
            out.println("    border-radius: 30px;");
            out.println("    cursor: pointer;");
            out.println("    text-decoration: none;");
            out.println("    font-weight: bold;");
            out.println("    transition: transform 0.3s;");
            out.println("}");
            out.println(".btn:hover { transform: translateY(-2px); }");
            out.println(".btn-primary { background: white; color: #059669; }");
            out.println(".btn-secondary { background: rgba(255,255,255,0.2); color: white; }");
            out.println("</style>");
            out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='success-card'>");
            out.println("<div class='success-icon'><i class='fas fa-check-circle'></i></div>");
            out.println("<h2>🎉 Order Placed Successfully!</h2>");
            out.println("<p>Your order has been placed with <strong>" + paymentMethod + "</strong></p>");
            out.println("<p>Order ID: #ORD" + System.currentTimeMillis() + "</p>");
            if(paymentMethod.equals("COD")) {
                out.println("<p>💵 Pay ₹" + String.format("%,.0f", total) + " when you receive the product</p>");
            } else {
                out.println("<p>✅ Payment successful! Amount: ₹" + String.format("%,.0f", total) + "</p>");
            }
            out.println("<div class='btn-group'>");
            out.println("<a href='MyOrdersServlet' class='btn btn-primary'><i class='fas fa-truck'></i> View Orders</a>");
            out.println("<a href='products.jsp' class='btn btn-secondary'><i class='fas fa-shopping-cart'></i> Continue Shopping</a>");
            out.println("</div>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}