package com.myservlet;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            System.out.println("=== Admin Login Attempt ===");
            System.out.println("Username: " + username);
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = 'admin'";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()) {
                String role = rs.getString("role");
                String fullName = rs.getString("full_name");
                int userId = rs.getInt("user_id");
                
                System.out.println("Admin Login SUCCESS for: " + username);
                
                HttpSession session = request.getSession(true);
                session.setAttribute("user", username);
                session.setAttribute("username", username);
                session.setAttribute("userId", userId);
                session.setAttribute("fullName", fullName);
                session.setAttribute("role", role);
                
                response.sendRedirect("admin-dashboard.jsp");
            } else {
                System.out.println("Admin Login FAILED for: " + username);
                RequestDispatcher rd = request.getRequestDispatcher("admin-login.jsp");
                rd.include(request, response);
                out.println("<div style='color:red; text-align:center;'>Invalid Admin Credentials!</div>");
            }
            
            rs.close();
            pst.close();
            con.close();
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}