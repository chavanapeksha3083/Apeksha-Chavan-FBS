package com.myservlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Get existing session (don't create new one)
            HttpSession session = request.getSession(false);
            
            if(session != null) {
                // Remove all attributes
                session.removeAttribute("user");
                session.removeAttribute("username");
                session.removeAttribute("userId");
                session.removeAttribute("role");
                session.removeAttribute("fullName");
                
                // Invalidate the session
                session.invalidate();
            }
            
            // Redirect to login page with logout message
            response.sendRedirect("login.jsp?msg=logout");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        doGet(request, response);
    }
}