package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ViewOrdersServlet")
public class ViewOrdersServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            String query = "SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.user_id ORDER BY o.order_date DESC";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            
            List<Map<String, Object>> orders = new ArrayList<>();
            while(rs.next()) {
                Map<String, Object> order = new HashMap<>();
                order.put("orderId", rs.getInt("order_id"));
                order.put("userId", rs.getInt("user_id"));
                order.put("username", rs.getString("username"));
                order.put("total", rs.getDouble("total_amount"));
                order.put("status", rs.getString("status"));
                order.put("paymentMethod", rs.getString("payment_method"));
                order.put("date", rs.getTimestamp("order_date"));
                orders.add(order);
            }
            
            session.setAttribute("allOrders", orders);
            
            rs.close();
            pst.close();
            con.close();
            
            response.sendRedirect("view-orders.jsp");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}