package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/UpdateProductServlet")
public class UpdateProductServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            int productId = Integer.parseInt(request.getParameter("productId"));
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            String category = request.getParameter("category");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String imageUrl = request.getParameter("imageUrl");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String sql = "UPDATE products SET name=?, description=?, price=?, category=?, quantity=?, image_url=? WHERE product_id=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setString(4, category);
            pst.setInt(5, quantity);
            pst.setString(6, imageUrl);
            pst.setInt(7, productId);
            int updated = pst.executeUpdate();
            pst.close();
            con.close();
            
            if(updated > 0) {
                response.sendRedirect("admin-dashboard.jsp?msg=product_updated");
            } else {
                response.getWriter().println("<script>alert('Update failed'); window.location='admin-dashboard.jsp';</script>");
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}