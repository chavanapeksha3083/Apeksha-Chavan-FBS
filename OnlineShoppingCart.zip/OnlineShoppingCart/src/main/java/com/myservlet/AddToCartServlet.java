package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int userId = (Integer) session.getAttribute("userId");
            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Check if product exists
            PreparedStatement checkProduct = con.prepareStatement("SELECT quantity FROM products WHERE product_id = ?");
            checkProduct.setInt(1, productId);
            ResultSet rs = checkProduct.executeQuery();
            int availableStock = 0;
            if(rs.next()) {
                availableStock = rs.getInt("quantity");
            }
            rs.close();
            checkProduct.close();
            
            if(availableStock <= 0) {
                response.setContentType("text/html");
                response.getWriter().println("<script>alert('Out of stock!'); window.location='products.jsp';</script>");
                return;
            }
            
            if(quantity > availableStock) {
                response.setContentType("text/html");
                response.getWriter().println("<script>alert('Only " + availableStock + " left in stock!'); window.location='product-detail.jsp?id=" + productId + "';</script>");
                return;
            }
            
            // Check if already in cart
            PreparedStatement checkCart = con.prepareStatement("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
            checkCart.setInt(1, userId);
            checkCart.setInt(2, productId);
            rs = checkCart.executeQuery();
            
            if(rs.next()) {
                int newQty = rs.getInt("quantity") + quantity;
                PreparedStatement update = con.prepareStatement("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
                update.setInt(1, newQty);
                update.setInt(2, userId);
                update.setInt(3, productId);
                update.executeUpdate();
                update.close();
            } else {
                PreparedStatement insert = con.prepareStatement("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
                insert.setInt(1, userId);
                insert.setInt(2, productId);
                insert.setInt(3, quantity);
                insert.executeUpdate();
                insert.close();
            }
            
            rs.close();
            checkCart.close();
            con.close();
            
            // Show success message and redirect
            response.setContentType("text/html");
            response.getWriter().println("<script>alert('Product added to cart successfully!'); window.location='ViewCartServlet';</script>");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}