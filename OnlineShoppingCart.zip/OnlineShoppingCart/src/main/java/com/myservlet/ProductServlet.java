package com.myservlet;

import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.bean.Product;
import serviceInterface.ShoppingServiceInterface;
import aspect.provider.ObjectProvider;

public class ProductServlet extends HttpServlet
{
    ShoppingServiceInterface service = ObjectProvider.createServiceObject();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null)
            {
                response.sendRedirect("login.jsp");
                return;
            }
            
            String category = request.getParameter("category");
            List<Product> products;
            
            if(category != null && !category.isEmpty())
            {
                products = service.getProductsByCategory(category);
            }
            else
            {
                products = service.getAllProducts();
            }
            
            session.setAttribute("products", products);
            response.sendRedirect("products.jsp");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}