package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/CancelOrderServlet")
public class CancelOrderServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            int userId = (Integer) session.getAttribute("userId");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Update order status to cancelled
            PreparedStatement pst = con.prepareStatement("UPDATE orders SET status = 'cancelled' WHERE order_id = ? AND user_id = ?");
            pst.setInt(1, orderId);
            pst.setInt(2, userId);
            pst.executeUpdate();
            pst.close();
            con.close();
            
            response.sendRedirect("MyOrdersServlet");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}