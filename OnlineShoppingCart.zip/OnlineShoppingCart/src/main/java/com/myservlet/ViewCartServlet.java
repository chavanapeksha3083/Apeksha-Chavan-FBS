package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ViewCartServlet")
public class ViewCartServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null) {
                response.sendRedirect("login.jsp");
                return;
            }
            
            int userId = (Integer) session.getAttribute("userId");
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            String query = "SELECT c.cart_id, c.quantity, p.product_id, p.name, p.price, p.mrp, p.image_url, p.quantity as stock FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            
            List<Map<String, Object>> cartItems = new ArrayList<>();
            double total = 0;
            
            while(rs.next()) {
                Map<String, Object> item = new HashMap<>();
                item.put("cartId", rs.getInt("cart_id"));
                item.put("productId", rs.getInt("product_id"));
                item.put("name", rs.getString("name"));
                item.put("price", rs.getDouble("price"));
                item.put("mrp", rs.getDouble("mrp"));
                item.put("quantity", rs.getInt("quantity"));
                item.put("stock", rs.getInt("stock"));
                item.put("image", rs.getString("image_url"));
                item.put("subtotal", rs.getDouble("price") * rs.getInt("quantity"));
                cartItems.add(item);
                total += rs.getDouble("price") * rs.getInt("quantity");
            }
            
            session.setAttribute("cartItems", cartItems);
            session.setAttribute("cartTotal", total);
            
            rs.close();
            pst.close();
            con.close();
            
            response.sendRedirect("cart.jsp");
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}