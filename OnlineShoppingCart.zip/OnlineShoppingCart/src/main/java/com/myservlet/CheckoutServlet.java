package com.myservlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class CheckoutServlet extends HttpServlet
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            HttpSession session = request.getSession(false);
            if(session == null || session.getAttribute("user") == null)
            {
                response.sendRedirect("login.jsp");
                return;
            }
            
            response.sendRedirect("checkout.jsp");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}