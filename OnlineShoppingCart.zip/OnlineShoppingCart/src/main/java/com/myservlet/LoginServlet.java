package com.myservlet;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    // ⚠️ CHANGE THIS TO YOUR MYSQL PASSWORD ⚠️
    private static final String DB_PASSWORD = "Apeksha@30";
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    {
        PrintWriter out = null;
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        try
        {
            response.setContentType("text/html");
            out = response.getWriter();
            
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            System.out.println("=== Login Attempt ===");
            System.out.println("Username: " + username);
            
            if(username == null || username.trim().isEmpty())
            {
                showError(request, response, out, "Username is required!");
                return;
            }
            
            if(password == null || password.trim().isEmpty())
            {
                showError(request, response, out, "Password is required!");
                return;
            }
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            rs = pst.executeQuery();
            
            if(rs.next())
            {
                String role = rs.getString("role");
                String fullName = rs.getString("full_name");
                int userId = rs.getInt("user_id");
                
                System.out.println("✅ Login SUCCESS for: " + username);
                System.out.println("Role: " + role);
                
                HttpSession session = request.getSession(true);
                session.setAttribute("user", username);
                session.setAttribute("username", username);
                session.setAttribute("userId", userId);
                session.setAttribute("fullName", fullName);
                session.setAttribute("role", role);
                
                String contextPath = request.getContextPath();
                
                // ✅ SHOW SUCCESS MESSAGE THEN REDIRECT
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<meta charset='UTF-8'>");
                out.println("<title>Login Successful</title>");
                out.println("<link rel='stylesheet' href='" + contextPath + "/style.css'>");
                out.println("<style>");
                out.println("body {");
                out.println("    background: linear-gradient(135deg, #0a0e27 0%, #0f172a 30%, #1e1b4b 70%, #0a0e27 100%);");
                out.println("    min-height: 100vh;");
                out.println("    display: flex;");
                out.println("    justify-content: center;");
                out.println("    align-items: center;");
                out.println("    font-family: 'Poppins', sans-serif;");
                out.println("}");
                out.println(".success-card {");
                out.println("    background: linear-gradient(135deg, rgba(15,23,42,0.95), rgba(10,14,39,0.98));");
                out.println("    padding: 50px;");
                out.println("    border-radius: 25px;");
                out.println("    text-align: center;");
                out.println("    border: 1px solid rgba(59,130,246,0.3);");
                out.println("    animation: fadeIn 0.5s ease;");
                out.println("    min-width: 400px;");
                out.println("}");
                out.println("@keyframes fadeIn {");
                out.println("    from { opacity: 0; transform: scale(0.9); }");
                out.println("    to { opacity: 1; transform: scale(1); }");
                out.println("}");
                out.println(".success-icon {");
                out.println("    width: 80px;");
                out.println("    height: 80px;");
                out.println("    background: linear-gradient(135deg, #10b981, #059669);");
                out.println("    border-radius: 50%;");
                out.println("    display: flex;");
                out.println("    align-items: center;");
                out.println("    justify-content: center;");
                out.println("    margin: 0 auto 25px;");
                out.println("}");
                out.println(".success-icon span {");
                out.println("    color: white;");
                out.println("    font-size: 50px;");
                out.println("    font-weight: bold;");
                out.println("}");
                out.println(".success-card h2 {");
                out.println("    background: linear-gradient(135deg, #60a5fa, #3b82f6);");
                out.println("    -webkit-background-clip: text;");
                out.println("    background-clip: text;");
                out.println("    color: transparent;");
                out.println("    margin-bottom: 15px;");
                out.println("}");
                out.println(".success-card p {");
                out.println("    color: #94a3b8;");
                out.println("    margin-bottom: 10px;");
                out.println("}");
                out.println(".username {");
                out.println("    color: #60a5fa;");
                out.println("    font-weight: bold;");
                out.println("}");
                out.println(".role {");
                out.println("    color: #f59e0b;");
                out.println("    margin: 15px 0;");
                out.println("}");
                out.println(".loader {");
                out.println("    width: 40px;");
                out.println("    height: 40px;");
                out.println("    border: 3px solid #1e293b;");
                out.println("    border-top: 3px solid #3b82f6;");
                out.println("    border-radius: 50%;");
                out.println("    margin: 20px auto 0;");
                out.println("    animation: spin 1s linear infinite;");
                out.println("}");
                out.println("@keyframes spin {");
                out.println("    0% { transform: rotate(0deg); }");
                out.println("    100% { transform: rotate(360deg); }");
                out.println("}");
                out.println(".redirect-text {");
                out.println("    color: #60a5fa;");
                out.println("    margin-top: 20px;");
                out.println("    font-size: 0.9rem;");
                out.println("}");
                out.println("</style>");
                out.println("</head>");
                out.println("<body>");
                out.println("<div class='success-card'>");
                out.println("<div class='success-icon'><span>✓</span></div>");
                out.println("<h2>✅ Login Successful!</h2>");
                out.println("<p>Welcome back, <span class='username'>" + username + "</span>!</p>");
                out.println("<div class='role'>🎯 Role: " + role.toUpperCase() + "</div>");
                
                if("admin".equals(role))
                {
                    out.println("<p>Redirecting you to <strong>Admin Dashboard</strong>...</p>");
                    out.println("<div class='loader'></div>");
                    out.println("<p class='redirect-text'>Please wait while we redirect you...</p>");
                    out.println("<script>");
                    out.println("setTimeout(function() {");
                    out.println("    window.location.href = '" + contextPath + "/admin-dashboard.jsp';");
                    out.println("}, 2000);");
                    out.println("</script>");
                }
                else
                {
                    out.println("<p>Redirecting you to <strong>Products Page</strong>...</p>");
                    out.println("<div class='loader'></div>");
                    out.println("<p class='redirect-text'>Please wait while we redirect you...</p>");
                    out.println("<script>");
                    out.println("setTimeout(function() {");
                    out.println("    window.location.href = '" + contextPath + "/products.jsp';");
                    out.println("}, 2000);");
                    out.println("</script>");
                }
                
                out.println("</div>");
                out.println("</body>");
                out.println("</html>");
            }
            else
            {
                System.out.println("❌ Login FAILED for: " + username);
                showError(request, response, out, "Invalid Username or Password!");
            }
        }
        catch(Exception e)
        {
            System.out.println("❌ Exception in LoginServlet:");
            e.printStackTrace();
            try {
                showError(request, response, out, "Error: " + e.getMessage());
            } catch(Exception ex) {}
        }
        finally
        {
            try { if(rs != null) rs.close(); } catch(Exception e) {}
            try { if(pst != null) pst.close(); } catch(Exception e) {}
            try { if(con != null) con.close(); } catch(Exception e) {}
        }
    }
    
    private void showError(HttpServletRequest request, HttpServletResponse response, PrintWriter out, String errorMsg) throws Exception
    {
        String contextPath = request.getContextPath();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>Login Failed</title>");
        out.println("<link rel='stylesheet' href='" + contextPath + "/style.css'>");
        out.println("<style>");
        out.println("body {");
        out.println("    background: linear-gradient(135deg, #0a0e27 0%, #0f172a 30%, #1e1b4b 70%, #0a0e27 100%);");
        out.println("    min-height: 100vh;");
        out.println("    display: flex;");
        out.println("    justify-content: center;");
        out.println("    align-items: center;");
        out.println("    font-family: 'Poppins', sans-serif;");
        out.println("}");
        out.println(".error-card {");
        out.println("    background: linear-gradient(135deg, rgba(15,23,42,0.95), rgba(10,14,39,0.98));");
        out.println("    padding: 50px;");
        out.println("    border-radius: 25px;");
        out.println("    text-align: center;");
        out.println("    border: 1px solid rgba(239,68,68,0.3);");
        out.println("    min-width: 400px;");
        out.println("}");
        out.println(".error-icon {");
        out.println("    width: 80px;");
        out.println("    height: 80px;");
        out.println("    background: linear-gradient(135deg, #ef4444, #dc2626);");
        out.println("    border-radius: 50%;");
        out.println("    display: flex;");
        out.println("    align-items: center;");
        out.println("    justify-content: center;");
        out.println("    margin: 0 auto 25px;");
        out.println("}");
        out.println(".error-icon span {");
        out.println("    color: white;");
        out.println("    font-size: 50px;");
        out.println("    font-weight: bold;");
        out.println("}");
        out.println(".error-card h2 {");
        out.println("    color: #f87171;");
        out.println("    margin-bottom: 15px;");
        out.println("}");
        out.println(".error-card p {");
        out.println("    color: #94a3b8;");
        out.println("    margin-bottom: 20px;");
        out.println("}");
        out.println(".back-link {");
        out.println("    display: inline-block;");
        out.println("    background: linear-gradient(135deg, #3b82f6, #1d4ed8);");
        out.println("    color: white;");
        out.println("    padding: 10px 25px;");
        out.println("    text-decoration: none;");
        out.println("    border-radius: 25px;");
        out.println("    margin-top: 10px;");
        out.println("    transition: all 0.3s;");
        out.println("}");
        out.println(".back-link:hover {");
        out.println("    transform: translateY(-2px);");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='error-card'>");
        out.println("<div class='error-icon'><span>✗</span></div>");
        out.println("<h2>❌ Login Failed!</h2>");
        out.println("<p>" + errorMsg + "</p>");
        out.println("<a href='" + contextPath + "/login.jsp' class='back-link'>Try Again</a>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}