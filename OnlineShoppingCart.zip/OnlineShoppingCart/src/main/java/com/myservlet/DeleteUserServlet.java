package com.myservlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/shoppingdb?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Apeksha@30";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession(false);
            if(session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect("admin-login.jsp");
                return;
            }
            
            int userId = Integer.parseInt(request.getParameter("userId"));
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            PreparedStatement pst = con.prepareStatement("DELETE FROM users WHERE user_id = ? AND role = 'customer'");
            pst.setInt(1, userId);
            pst.executeUpdate();
            pst.close();
            con.close();
            
            response.sendRedirect("admin-dashboard.jsp?msg=user_deleted");
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}