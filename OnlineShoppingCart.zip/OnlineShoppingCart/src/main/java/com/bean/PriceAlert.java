package com.bean;

import java.sql.Timestamp;

public class PriceAlert {
    private int alertId;
    private int userId;
    private int productId;
    private double targetPrice;
    private double currentPrice;
    private boolean isNotified;
    private Timestamp createdAt;
    private Product product;
    
    public PriceAlert() {}
    
    public PriceAlert(int userId, int productId, double targetPrice) {
        this.userId = userId;
        this.productId = productId;
        this.targetPrice = targetPrice;
    }
    
    // Getters and Setters
    public int getAlertId() { return alertId; }
    public void setAlertId(int alertId) { this.alertId = alertId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public double getTargetPrice() { return targetPrice; }
    public void setTargetPrice(double targetPrice) { this.targetPrice = targetPrice; }
    
    public double getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(double currentPrice) { this.currentPrice = currentPrice; }
    
    public boolean isNotified() { return isNotified; }
    public void setNotified(boolean notified) { isNotified = notified; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }
}