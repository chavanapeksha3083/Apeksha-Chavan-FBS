package com.bean;

import java.sql.Timestamp;

public class StockNotification {
    private int notifyId;
    private int userId;
    private int productId;
    private String email;
    private boolean isNotified;
    private Timestamp createdAt;
    private Product product;
    
    public StockNotification() {}
    
    public StockNotification(int userId, int productId, String email) {
        this.userId = userId;
        this.productId = productId;
        this.email = email;
    }
    
    // Getters and Setters
    public int getNotifyId() { return notifyId; }
    public void setNotifyId(int notifyId) { this.notifyId = notifyId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public boolean isNotified() { return isNotified; }
    public void setNotified(boolean notified) { isNotified = notified; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }
}