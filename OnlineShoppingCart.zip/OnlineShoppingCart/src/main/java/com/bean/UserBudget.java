package com.bean;

public class UserBudget {
    private int budgetId;
    private int userId;
    private double monthlyBudget;
    private int alertPercentage;
    
    public UserBudget() {}
    
    public UserBudget(int userId, double monthlyBudget, int alertPercentage) {
        this.userId = userId;
        this.monthlyBudget = monthlyBudget;
        this.alertPercentage = alertPercentage;
    }
    
    // Getters and Setters
    public int getBudgetId() { return budgetId; }
    public void setBudgetId(int budgetId) { this.budgetId = budgetId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public double getMonthlyBudget() { return monthlyBudget; }
    public void setMonthlyBudget(double monthlyBudget) { this.monthlyBudget = monthlyBudget; }
    
    public int getAlertPercentage() { return alertPercentage; }
    public void setAlertPercentage(int alertPercentage) { this.alertPercentage = alertPercentage; }
}