package com.bean;

import java.sql.Timestamp;

public class Order
{
    private int orderId;
    private int userId;
    private double totalAmount;
    private String status; // "pending", "completed", "cancelled"
    private String paymentMethod;
    private String cardNumber;
    private Timestamp orderDate;
    
    public Order() {}
    
    public Order(int userId, double totalAmount, String paymentMethod, String cardNumber)
    {
        this.userId = userId;
        this.totalAmount = totalAmount;
        this.status = "completed";
        this.paymentMethod = paymentMethod;
        this.cardNumber = cardNumber;
    }
    
    public int getOrderId() { return orderId; }
    public void setOrderId(int orderId) { this.orderId = orderId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    
    public String getCardNumber() { return cardNumber; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
    
    public Timestamp getOrderDate() { return orderDate; }
    public void setOrderDate(Timestamp orderDate) { this.orderDate = orderDate; }
}