package com.bean;

public class CartItem
{
    private int cartId;
    private int userId;
    private Product product;
    private int quantity;
    private double subtotal;
    
    public CartItem() {}
    
    public CartItem(Product product, int quantity)
    {
        this.product = product;
        this.quantity = quantity;
        this.subtotal = product.getPrice() * quantity;
    }
    
    public int getCartId() { return cartId; }
    public void setCartId(int cartId) { this.cartId = cartId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) 
    { 
        this.quantity = quantity;
        this.subtotal = product.getPrice() * quantity;
    }
    
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
}