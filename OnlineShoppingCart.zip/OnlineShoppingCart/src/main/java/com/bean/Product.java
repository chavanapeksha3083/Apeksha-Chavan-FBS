package com.bean;

public class Product
{
    private int productId;
    private String name;
    private String description;
    private double price;
    private String category;
    private int quantity;
    private String imageUrl;
    
    public Product() {}
    
    public Product(String name, String description, double price, String category, int quantity, String imageUrl)
    {
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
    }
    
    // Getters and Setters
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    @Override
    public String toString()
    {
        return "Product [productId=" + productId + ", name=" + name + ", price=" + price + 
               ", category=" + category + ", quantity=" + quantity + "]";
    }
}